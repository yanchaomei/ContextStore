# ContextStore

**Tiered shared storage for LLM inference KV caches.**

## RailFuse competition entry and demonstration (2026-10-16 V4)

This fork's research branch adds object-aware multi-rail client reads, optional direct ordered private staging, and explicit publication/retirement boundaries. It builds on the upstream ContextStore service, protocol and storage layout.

- [Detailed project introduction (Chinese PDF, 29 pages / 8 figures)](kv-service/verification/results/competition-demo-20261016-v4/RailFuse-project-introduction-v4.pdf)
- [4:30 demonstration with neural female narration](kv-service/verification/results/competition-demo-20261016-v4/RailFuse-demo-v4.mp4)
- [Step-by-step presenter guide (Chinese PDF)](kv-service/verification/results/competition-demo-20261016-v4/RailFuse-demo-guide-v4.pdf)
- [V4 illustrations, narration, subtitles and independent review](kv-service/verification/results/competition-demo-20261016-v4/)
- [Reusable competition material-production skill](kv-service/verification/results/competition-demo-20261016-v4/workflow-skill/SKILL.md)
- [Live demo scripts, timed terminal capture and raw receipts](kv-service/verification/results/competition-demo-20261016-v2/)
- [Frozen FFI/Python safety acceptance and independent reviews](kv-service/verification/results/ffi-lifecycle-20261016/)

The story follows three decisions: **plan the paths, validate before publication, retire DMA ownership before reuse**. The optional Rust direct path writes disjoint regions of one request-private ordered buffer; Python's legacy FFI remains a separate single-connection interface with explicit lifetime obligations.

<img src="kv-service/verification/results/competition-demo-20261016-v2/assets/mechanism-overview.png" alt="RailFuse planning, publication and lifetime boundaries" width="100%">

Historical same-plan direct/packed-contiguous RXE comparisons give 1.100x (64 MiB) and 1.161x (256 MiB) paired throughput ratios over ten process blocks per size. The October 12 witness records eight reads with observed Generation growth and safe rejection. The new October 16 live capture demonstrates a 64 MiB write/read, matching single/dual-rail hashes, genuine baseline late-WRITE corruption, fixed-buffer recovery, and three same-registration PUT/GET recovery rounds. Dates and scopes remain separate; these software-RoCE results do not establish physical dual-HCA aggregation or end-to-end inference speedup.

ContextStore extends the KV cache from a single node's GPU HBM out to host memory, local NVMe, and remote JBOF / NVMe-oF pools. It gives vLLM / Dynamo inference workers cross-instance, cross-session KV reuse so long-context and multi-replica deployments avoid repeating prefill on cache-warm prefixes.

The repository is split into two independently built parts, plus a thin plugin layer:

| Part | Path | Language | Role |
|------|------|----------|------|
| **ContextStore Connector** | `src/contextstore/` | Python | vLLM / Dynamo `KVConnector` plugin. Owns codec, prefix index, scheduler/worker split, tiered cache, and the KVService client. |
| **KVService** | `kv-service/` | Rust | Standalone distributed block-storage service for JBOF / NVMe-oF. Exposes gRPC + RDMA data paths. |
| NIXL plugin | `nixl-plugin/` | C++ / Rust | Loads ContextStore as NIXL's `CONTEXTSTORE` backend under the `OBJ` descriptor contract. |

KVService is consumer-agnostic: besides the in-repo Connector and NIXL plugin,
external KV-cache managers integrate through `kv-service/client-rs` (Rust SDK,
gRPC + RDMA including SGE scatter reads) or the gRPC API directly — this is the
path used by redhare's cold-tier backend.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        vLLM / Dynamo                            │
└──────┬──────────────────────┬──────────────────────┬────────────┘
       │ KVConnector API      │ KVConnector API      │ NIXL OBJ
       ▼                      ▼                      ▼
┌──────────────────┐  ┌───────────────────┐  ┌──────────────────┐
│ ContextStore     │  │ external KV mgr   │  │ NIXL plugin      │
│ Connector        │  │ (e.g. redhare     │  │ (nixl-plugin/)   │
│ (src/contextstore)│ │ cold tier)        │  │                  │
│ Codec · Prefix   │  │        │          │  │                  │
│ Index · L1/L2    │  │        ▼          │  │                  │
│ tiers            │  │ client-rs SDK     │  │                  │
└────────┬─────────┘  │ (kv-service/      │  └────────┬─────────┘
         │            │  client-rs)       │           │
         │            └────────┬──────────┘           │
         │ gRPC               │ gRPC ctl + RDMA data  │
         │                    │ (multi-endpoint, SGE  │
         │                    │  scatter direct-write)│
         ▼                    ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                   KVService cluster (kv-service/)               │
│                                                                 │
│   ┌── node A ─────────────┐      ┌── node B ─────────────┐      │
│   │ MemoryTier (RDMA slab,│      │ MemoryTier (RDMA slab,│      │
│   │  pre-registered)      │      │  pre-registered)      │      │
│   │ StorageTier           │      │ StorageTier           │      │
│   │  io_uring O_DIRECT    │      │  io_uring O_DIRECT    │      │
│   │  NVMe · NVMe · …      │      │  NVMe · NVMe · …      │      │
│   └───────────────────────┘      └───────────────────────┘      │
│      objects ≥ threshold are striped across nodes & disks;      │
│      readers pull each node's stripes concurrently              │
└───────────────────────────────┬─────────────────────────────────┘
                                │ placement metadata
                                ▼
                        ┌──────────────┐
                        │    Redis     │
                        └──────────────┘
```

Consumers and KVService are built and deployed independently. Each consumer
(the in-repo Connector, an external KV manager over client-rs, or the NIXL
plugin) owns its KV semantics; KVService owns shared capacity, cross-node
striping, and the high-bandwidth data paths. The RDMA data path serves reads
via multi-endpoint stripe-subset GETs — optionally with an SGE segment list so
the server writes straight into the caller's scattered destination buffers —
and control messages travel on a TCP side channel (NODELAY). Nothing depends
on anything else at build time.

---

## KVService object model & metadata

KVService exposes an **object store** (not a byte-addressable KV): each write produces an object identified by `ObjectKey{namespace, object_key}`, and each object carries server-generated metadata that clients treat as opaque.

**Metadata service (Rust side).** `MetadataService` (`kv-service/server/src/metadata.rs`) persists per-object records in a shared Redis metadata store. Each `BlockMeta` includes:

| Field | Meaning |
|-------|---------|
| `object_handle` | Opaque read handle generated by the server; clients round-trip it verbatim |
| `object_generation` | Content generation; monotonically increases on overwrite of the same key |
| `content_etag` | Lightweight content-identity token (avoids re-hashing large payloads on every GET) |
| `layout_version` | Physical layout version; bumped by rebalance / migration without changing content |
| `striping` | Optional `StripingInfo{chunk_size, chunk_devices, chunk_paths, total_size, chunk_locations, chunk_checksums}` for objects striped across multiple NVMe / nodes |

**Descriptor-based reads.** The gRPC surface splits read into two RPCs:

- `LookupObject` returns an `ObjectDescriptor` (identity + `layout_version` + size + stripe count) and a `PlacementDescriptor` (which node / device / RDMA endpoint holds each stripe). No payload bytes are returned.
- `ReadByDescriptor` / `ReadByDescriptorStream` takes a client-cached descriptor and returns the payload. The server verifies the descriptor first; if the object was rewritten or relocated, the server replies `FAILED_PRECONDITION` and the client re-runs `LookupObject`.

**Speculative concurrent lookup + read (client side).** `KVClient.get_stream_chunks_cached` (`src/contextstore/kvservice_client/client.py`) hides the round-trip cost of validation:

- On a **cache miss**, do `LookupObject` → `ReadByDescriptor` sequentially and cache the result.
- On a **cache hit**, fire `LookupObject` and `ReadByDescriptor(cached_descriptor)` **concurrently**. If identity matches, return the read; if only `layout_version` changed but `content_etag` matches, still return the read and refresh the cache; only on content mismatch does the client re-read using the fresh descriptor.

This keeps hot GETs to a single round trip while remaining correct under concurrent overwrite / rebalance.

**Multi-node placement.** For striped objects the coordinator uses `PutPlacementChunk` / `ReadPlacementChunk` / `DeletePlacementChunk` to write individual stripes directly to the data node that owns them, keyed off `PlacementChunk{stripe_index, node_id, grpc_endpoint, rdma_endpoint, device_id, storage_handle, offset, length}`. Clients that hold a fresh `PlacementDescriptor` can bypass the coordinator and read the primary node directly — this is what unlocks the RDMA fast path.

**Multi-endpoint + SGE reads.** A reader groups an object's stripes by owning node and issues one stripe-subset GET per node concurrently, so aggregate cold-read bandwidth scales with node count. The SGE variant (wire tag 15) additionally carries the client's destination segment list, letting the server RDMA-WRITE each byte range straight into the caller's scattered buffers — no client-side staging copy. Both RDMA control-plane sockets run with `TCP_NODELAY`. Measured on 2 nodes × 2 NVMe (fio ceiling ~28 GB/s): 6.4–8.8 GB/s per synchronous client stream, 23 GB/s aggregate at 8 concurrent streams, disk-byte-accounted cold reads.

---

## Quick start

### 1. Install the Python library

```bash
git clone git@github.com:DaoCloud/ContextStore.git
cd ContextStore
pip install -e .            # Connector + KVService client
pip install -e '.[test]'    # adds pytest / fakeredis
# Only needed after editing kv-service/proto/kv_service.proto.
pip install -e '.[proto]'   # adds grpcio-tools for `make proto`
```

### 2. Build and run KVService (optional L3 tier)

```bash
# Build server / client-rs / rdma-ffi with the deployment feature set.
make build

# Build and start the server in the foreground (logs stay in this terminal).
make deploy
```

KVService reads one TOML config file and requires a reachable Redis metadata
store. See [`kv-service/configs/README.md`](kv-service/configs/README.md) for
the config file format and examples.

For **production installation on storage nodes** (immutable release
directories, atomic activation, hardened systemd unit, post-upgrade acceptance
checklist), use the versioned toolkit at
[`deploy/baremetal/`](deploy/baremetal/README.md). Container and JBOF/NVMe-oF
topologies are covered in
[`kv-service/deploy/README.md`](kv-service/deploy/README.md).

`make build` enables the RDMA data path, Tier B `io-uring`, and Prometheus
metrics. It produces the server, Rust client SDK, and RDMA C ABI under
`target/release/`. Before building, it prints the selected profile, features,
and protobuf compiler. `protoc` is discovered from an explicit `PROTOC`, a
bundled repository tool, `/opt/contextstore/tools/protoc`, or the system
`PATH`, in that order. Regenerate Python protobuf bindings only after changing
the protocol:

```bash
make proto
```

`make deploy` always runs the freshly built binary and does not change an
installed systemd service or copy artifacts into `/opt`. Select another TOML
file with `CONFIG=/path/to/server.toml`; RDMA deployment variables are passed
through unchanged:

```bash
CS_RDMA_DEVICES=mlx5_1:0.0.0.0:50053 \
CS_FORCE_DISK_READ=1 \
make deploy CONFIG=/etc/contextstore/rdma-bench.toml
```

Inspect Redis metadata without manually constructing a canonical key:

```bash
make meta
./target/release/cs-meta --config /etc/contextstore/rdma-bench.toml namespaces

./target/release/cs-meta --config /etc/contextstore/rdma-bench.toml \
  get --namespace rust-bench --object-key 'rdma-checksum0/__combined__'

./target/release/cs-meta --config /etc/contextstore/rdma-bench.toml \
  list --namespace rust-bench --object-prefix rdma-checksum
```

The `namespaces` command shows all current namespaces and object counts. The
`list` command shows every current key in a namespace; `get` adds every stripe
path, device, and checksum status for one key. Use `--json` for machine-readable
output. Pass `--limit <count>` to truncate a large namespace listing.

For a direct RDMA read benchmark, prefer the readable selector over a manually
constructed canonical key:

```bash
./target/release/cs-rdma-bench \
  --server 127.0.0.1:50053 \
  --device mlx5_0 \
  --namespace rust-bench \
  --object-key 'rdma-checksum0/__combined__' \
  --buf-mb 1024 \
  --iters 10
```

`--key` remains available for protocol debugging and accepts the internal
`<namespace-byte-length>:<namespace><object-key>` form.

### 3. Wire the Connector into vLLM

Pass a `--kv-transfer-config` to vLLM v1:

```json
{
  "kv_connector": "ContextStoreConnector",
  "kv_connector_module_path": "contextstore.connector",
  "kv_role": "kv_both",
  "kv_connector_extra_config": {
    "model_id": "Qwen2.5-32B",
    "kv_service_endpoint": "10.0.0.1:50051",
    "host_memory_capacity_gb": 128,
    "kv_service_parallel_channels": 1,
    "rdma_enabled": true,
    "rdma_server_addr": "10.0.0.1:50053",
    "rdma_device": "mlx5_0"
  }
}
```

All keys map directly to fields on `ContextStoreConfig` (`src/contextstore/core/config.py`). Multi-endpoint HA is enabled by passing `kv_service_endpoints: ["host1:50051", "host2:50051"]` instead of a single endpoint.

### 4. Or wire into Dynamo

Dynamo loads the same Connector under the KVBM contract, with a `contextstore.*` dotted-alias layer:

```json
{
  "kv_connector": "DynamoConnector",
  "kv_connector_module_path": "contextstore.integrations.dynamo.connector",
  "kv_role": "kv_both",
  "kv_connector_extra_config": {
    "contextstore.model_id": "Qwen2.5-32B",
    "contextstore.endpoint": "10.0.0.1:50051",
    "contextstore.host_memory_capacity_gb": 128,
    "contextstore.rdma_enabled": true
  }
}
```

Both dotted (`contextstore.foo`) and nested (`{"contextstore": {"foo": ...}}`) forms are accepted; see `_DOTTED_ALIASES` in `src/contextstore/integrations/dynamo/connector.py` for the full list.

---

## Repository layout

```
ContextStore/
├── src/contextstore/       # Python library (Connector + KVService client SDK)
├── kv-service/             # Rust KV Service (server, client-rs, rdma-ffi, configs, deploy)
├── nixl-plugin/            # NIXL CONTEXTSTORE backend (C++ plugin + Rust FFI)
├── tests/                  # Python pytest suite (no GPU / Redis required)
├── Makefile                 # Root build, test, and deployment entry points
├── pyproject.toml
├── CLAUDE.md               # Development conventions
└── LICENSE
```

---

## Build and test

### Python

```bash
pip install -e '.[test]'
pytest tests/ -v
```

### Rust

```bash
make build                     # server + client-rs + rdma-ffi, deployment features enabled
make server                    # build only contextstore-server
make client-rs                 # build only the Rust client SDK
make rdma-ffi                  # build only the Python ctypes C ABI library
make test-server               # Rust server tests
make test-integration          # requires a running server
make e2e                       # isolated Redis + two local KVService nodes
make fmt                       # format Rust code
make lint                      # run Rust clippy checks
```

`make build BUILD_TYPE=debug` builds the same artifacts with Cargo's debug
profile. `make proto`, `make proto-rust`, and `make proto-python` regenerate
protocol bindings; the Python targets require `grpcio-tools`.

`make e2e` is hardware-independent. It starts an ephemeral Redis and two
loopback-only KVService processes with isolated data directories, then verifies
streaming I/O, shared metadata, cross-node stripe placement, node restart
recovery, and distributed deletion. It requires `redis-server` and the Python
toolchain used to build KVService, but never uses or modifies a configured
Redis instance.

### Benchmarks

```bash
./target/release/cs-kvservice-bench --help
./target/release/cs-bench --help
./target/release/cs-rdma-bench --help
python kv-service/benchmarks/run_benchmark.py --endpoint localhost:50051
```

Run the Python benchmark wrapper through the root Makefile with:

```bash
make bench
```

### Multi-rail descriptor reads (experimental)

The [five-act competition story](docs/story.md) explains the problem, mechanism
and evidence boundary. The [design and verification note](docs/multi-rail-design.md)
records route semantics, memory ownership, failure behavior, budgets, upgrade
order and measured limits.

The Rust SDK can read one striped object over multiple local RDMA devices and
listeners on the same owning storage node. This uses the existing descriptor
GET and tag-15 SGE protocol; object placement and disk stripes are unchanged.
`LookupObject` advertises one primary RDMA endpoint per node. New servers can
also attach optional, ephemeral fabric/listener capabilities to Placement;
`RailReader::discover_from_placement` matches those with locally configured
fabric/device/port/GID paths. The server does not need to change or persist
the object's disk stripes. Old clients ignore the extra protobuf field, and
existing explicit `RailRoute` configurations remain usable with old servers.
Different rail entries for one node must use different local device/port pairs
and different remote listeners. A seventh comma-separated rail field may set
a positive relative scheduling weight; omitted weights default to 1. The
reader also reports each local device's sysfs NUMA node and PCI address when
the host exposes them.

```bash
# Manual listener mapping against an already stored striped object.
# Set the server's CS_RDMA_DEVICES for both listeners.
./target/release/cs-rail-read-bench \
  --environment physical --coordinator http://10.0.0.1:50051 \
  --namespace bench --object-key large-object \
  --rail 'r0,mlx5_0,10.0.0.1:50053,10.0.0.1:50053,1,3' \
  --rail 'r1,mlx5_1,10.0.0.1:50053,10.0.1.1:50054,1,3' \
  --warmup 1 --iterations 5
```

For discovered listeners, configure `[[cluster.rdma_rails]]` on the owning
server, as in [the two-RXE example](kv-service/configs/server-softroce-vm.toml).
The client still selects trusted local Verbs devices and fabric IDs, while
`LookupObject` supplies the remote listeners:

```bash
./target/release/cs-rail-read-bench \
  --environment soft-roce --coordinator http://10.31.0.2:55151 \
  --namespace rust-bench --object-key large-object \
  --local-rail 'r0,fabric-a,rxe_c0,1,1' \
  --local-rail 'r1,fabric-b,rxe_c1,1,1' \
  --warmup 1 --iterations 5
```

The CLI looks up the object before constructing its reader. SDK callers can
call `lookup_object`, then `RailReader::discover_from_placement`, then the
unchanged `read_multi_rail_into` entry point. Discovery rejects an owner or
fabric mismatch; if advertised capabilities change, rebuild the reader. It
does not silently fall back to an arbitrary listener; use
the explicit `--rail` mode for a server without advertised capabilities.
A fixed limit of 32 configured routes caps per-request worker/QP creation
before any RDMA connection is opened, without changing the public `RailLimits`
struct shape.
The [discovery design and upgrade tests](docs/rail-capability-discovery.md)
record the wire contract and one/two-rail compatibility behavior.

Use only the first `--rail` or `--local-rail` for a comparable single-rail run. The CLI labels
physical RDMA and Soft-RoCE separately, reports per-rail bytes, and hashes
every returned object. Set the server's cache policy and disk-read forcing
identically for both runs; these flags cannot prove a network bottleneck by
themselves. The SDK's `KvClient::read_multi_rail_into` rechecks descriptor and
placement identity after the transfer and publishes bytes only after all
rails and available checksums succeed. To enforce per-stripe checksum
validation, enable `verify_stripe_checksums` on the server and rewrite the
objects being tested so their placements contain checksums. With the server's
default setting, older placements may have no checksums. Cancellation and
publishing share a gate, so whichever starts first determines the result;
a failed or cancelled read leaves its caller buffer unchanged. Each rail owns
a compact registered receive buffer. The reader bounds concurrent tasks and
aggregate in-flight bytes per rail across simultaneous requests. It retains
the active-read and final-staging budget through the post-read lookup and
publish step; transfer and MR reservations end after all rail workers finish.
On Linux, the reader caps its registered-memory budget at 80% of the process's
soft `RLIMIT_MEMLOCK` when finite, rejecting excess reads before dispatch.
Multiple independent RailReader instances still need a deployment-wide
budget. No in-request transparent retry is attempted.
The server's stripe-subset fallback also honors tag-15 scatter destinations
when its registered slab cannot provide staging space. A fallback WRITE with
uncertain completion retains its source and MR until its QP is destroyed.
Uncertain CQ completion terminates the server connection rather than reusing
that CQ for another request; a client GET control error likewise destroys its
QP so a late reply cannot be mistaken for a new request's response. This also
applies to the older complete-object GET: cache-hit slab pins, cache-miss slab
extents, and per-chunk fallback MRs remain alive until their QP is destroyed
when a posted WRITE has uncertain completion. A cache-miss CQ error cannot
enter fallback on the same QP/CQ.

For hardware-independent scheduling and failure checks, run
`cargo test --manifest-path kv-service/client-rs/Cargo.toml --features rdma
rail_read::tests`. The ignored `rail_read_e2e` suite contains six single
real-Rail checks and seven dual-Rail/control-connection checks. Select a test with `--ignored
--exact <test_name> --nocapture` and configure `CS_RAIL_COORDINATOR`,
`CS_RAIL_LISTENER0/1`, `CS_RAIL_DEVICE0/1`, and `CS_RAIL_GID0/1` as needed.
`CS_RDMA_SLAB_MB=0` on the server exercises the registered-buffer fallback.
On an isolated server only, `CS_RDMA_TEST_PRE_WRITE_DELAY_MS=3000` delays
stripe-subset WRITEs for the late-completion test; the delay is bounded to
five seconds. Add `CS_RDMA_TEST_PRE_WRITE_NIC_IDX=1` to delay only the second
listener and exercise partial completion. `CS_RDMA_CQ_TIMEOUT_MS` bounds the
stripe-subset and legacy GET CQ polls between 100 and 30,000 ms (default
30,000); use 2,000 ms for isolated late-WRITE injection. Unset both
fault-injection variables after testing. With `CS_FORCE_DISK_READ=1` on an
isolated server, the ignored `legacy_get_timeout_retires_qp_before_buffer_reuse`
test completes the QP handshake first, then applies a 1 ms GET deadline. The
matching RXE receipt records a 2 s server CQ timeout, connection retirement,
and an unchanged reused destination after six seconds. A physical-stripe corruption
test additionally requires checksum verification enabled before writing its
object and a reversible fault injection into one test-only stripe file.
The ignored `software_only_mock_benchmark` exercises scheduling and memory
copies; its throughput is **not** an RDMA hardware result. Reproduce its
paired 1/2-rail matrix and save all per-read samples with
`python kv-service/benchmarks/collect_rail_mock.py --sizes 64,256,512`.
The checked-in `kv-service/benchmarks/results/2026-10-02-independent-rail-mock-*`
files contain one Linux ARM64 software-only run, including environment details.
The `2026-10-02-skv-x86-rail-mock-*` files repeat the same paired matrix on
an x86_64 two-socket host; their much lower absolute copy rate is a reminder
that Mock results are host-specific software measurements.
The separate `kv-service/benchmarks/results/2026-10-02-skv-single-hca.json`
records physical single-rail Verbs reads, HCA port-counter deltas, fault tests,
and the storage/topology boundary. It does not measure two-rail aggregation.
Use `kv-service/configs/server-rail-validation.toml` as a small, checksummed
server example. For real Verbs performance,
`kv-service/benchmarks/collect_rail_verbs.py` pairs one
and two rails on the same prewritten objects and saves every latency sample,
CPU time, RSS, and per-rail bytes. Label RXE runs `soft-roce`: RXE executes the
Verbs path but does not establish HCA offload or physical link aggregation.
The CLI's `--concurrency N` option (1–8) runs N complete object reads within
one process and one shared RailReader, reporting per-request latency and
aggregate throughput. `kv-service/benchmarks/collect_rail_concurrent.py`
collects paired 1/2-rail batches for concurrency levels above one; it preserves
the same object, server, layout, and concurrency within each comparison.

#### Reproduce two independent Soft-RoCE rails in isolated VMs

The scripts in `kv-service/deploy/softroce-vm/` build two Ubuntu 22.04 KVM
guests on a Linux x86_64 host. They create two test-only tap/bridge pairs with
no production NIC attached. Each guest receives two virtio NICs; four RXE
devices expose separate GIDs and listeners. The VM uses about 8 GiB RAM total
plus sparse qcow2 overlays. Install QEMU/KVM, `genisoimage`, `iproute2`,
`curl`, `tmux`, and Rust/Verbs build dependencies on the host first.

```bash
export CS_VM_DIR=/absolute/path/to/test-only/vm
export CS_VM_SSH_PUBLIC_KEY=/absolute/path/to/test-key.pub
export CS_VM_TAP_USER="$(id -un)"
kv-service/deploy/softroce-vm/prepare-pair.sh
kv-service/deploy/softroce-vm/setup-host-bridges.sh
kv-service/deploy/softroce-vm/start-pair.sh
```

`prepare-pair.sh` verifies Ubuntu's published SHA-256 before boot. Copy
`kv-service/deploy/softroce-vm/ssh_config.example` outside the repository,
replace its KVM host alias and private key path, and set `CS_VM_SSH_CONFIG` to
that file. Run `install-guest-prereqs.sh` and `setup-guest-paths.sh server`
inside the server guest; use `setup-guest-paths.sh client` inside the client
guest. The latter creates `rxe_c0/rxe_c1` and `rxe_s0/rxe_s1` over distinct
`10.31.0.0/24` and `10.32.0.0/24` virtual paths. Check both links with
`rdma link show` and `ping` before running ContextStore.

Build Linux x86_64 binaries with `build-verbs.sh`. From the Linux build host,
set `CS_VM_SSH_CONFIG` and run `deploy-verbs.sh`; set `CS_E2E_BIN` to the
executable printed by `cargo test --test rail_read_e2e --no-run` if deploying
the ignored hardware tests. The example server config assumes guest user
`railtest`; edit its paths when using another user. Start
`start-guest-server.sh` inside the server guest, then write a striped object
from the client guest with `cs-bench --combined --stream --bytes-pass --only-put`.
Use `cs-rail-read-bench` with one `--rail` and then both rails, or the paired
`collect_rail_verbs.py` script. Every measurement must be labeled `soft-roce`.

The recorded VM run has [90 sequential samples](kv-service/benchmarks/results/softroce-vm-paired-samples.csv),
[concurrent samples](kv-service/benchmarks/results/softroce-vm-concurrent-64-128-samples.csv),
and [topology/counter evidence](kv-service/benchmarks/results/softroce-vm-topology.json).
`analyze_rail_verbs.py` recomputes descriptive medians and p95 from those
CSVs. For cleanup, stop the test server, run `teardown-guest-paths.sh` in
both guests, power them off, run `stop-pair.sh` if needed, then
`teardown-host-bridges.sh`. These names target only the test-only resources.

| Deployment / data path | Build and behavior evidence | Performance conclusion |
| --- | --- | --- |
| gRPC-only Rust SDK, no `rdma` feature | Builds without libibverbs; prior Redis two-node integration and Python suites pass | Existing path unchanged |
| One ConnectX-6 Dx HCA rail, Linux x86_64 | Real Verbs object, failure, checksum, late-WRITE and buffer-reuse checks | Single-rail only; test stripes share one SATA SSD |
| Two RXE rails in isolated Ubuntu KVM guests | Real Verbs single/dual reads, generation, checksum, path fault, cancellation, partial completion, late WRITE and registered-memory limits | Software RoCE/QEMU scaling only; no HCA or separate-NVMe claim |
| Two physical HCA rails | Not run: only one HCA port was online on each available SKV node | No physical aggregation claim |
| Linux ARM64 | Earlier RDMA/Mock and server feature suites pass; latest CQ/timeout changes were checked on x86_64 | No ARM64 hardware measurement |

#### Research branch: direct ordered private staging

The `research/direct-ordered-staging` branch adds opt-in `RailLimits::direct_staging` and a `contiguous_schedule` packed control. Both default to `false`. Eligible single-owner striped objects use consecutive weighted stripe runs and disjoint mutable slices of one request-private ordered vector; other placements retain the existing packed path. The disk stripe layout and `KvClient::read_multi_rail_into` signature are unchanged. The [mechanism diagram](docs/paper/figures/direct-vs-packed-2026-10-09-v1/contextstore-direct-vs-packed_en.svg), [safety contract](docs/paper/safety-contract.md), [complete evaluation](docs/paper/direct-staging-eval-2026-10-09.md) and [Chinese research summary](docs/paper/中文研究摘要与验收边界-2026-10-09.md) explain the route guard, QP/MR lifetime, evidence and limits.

The [five-arm collector](kv-service/benchmarks/collect_rail_modes.py) and [raw-log auditor](kv-service/benchmarks/audit_rail_modes.py) compare both optimized one-Rail paths, original packed-greedy, same-plan packed-contiguous and direct-contiguous. After seeding the two documented objects in the isolated VM setup above, [`run_rxe_five_arm_20261009.sh`](kv-service/benchmarks/run_rxe_five_arm_20261009.sh) runs the fixed ten-block protocol. The [final raw 64/256 MiB receipts](kv-service/benchmarks/results/paper-direct-final-2026-10-09/) include every process log, identity/stripe/Rail audit, fault logs, binary hashes and topology. The final-binary primary direct/same-plan packed throughput ratios are **1.100×** and **1.161×** on **software RXE**. They do not establish physical multi-HCA aggregation. The prior [six-paper venue audit](docs/paper/top-venue-methods.md) identifies Mooncake FAST '25 multi-NIC transfer as direct prior art; this branch's narrow contribution is the versioned object/failure contract plus a controlled reduction in software staging cost.

The [bounded two-Rail state explorer](kv-service/verification/multirail_state_explorer.py) and its [result/assumptions](docs/paper/safety-model-plan.md) test an abstract ownership contract; they do not prove the Rust/provider implementation. The test-only [Verbs return-value shim](kv-service/verification/verbs_failstop_shim.c) exercises QP/MR fail-stop cleanup in an isolated guest, not on production devices. The separate Python/`rdma-ffi` external-buffer path is outside the direct-staging safety claim.

The [concurrent rewrite and server fault supplement](docs/paper/rewrite-race-and-server-failstop-2026-10-09.md) uses unique bytes for every committed Generation and compares them with SDK-accepted IDs. Two final real-RXE runs prepare each payload before timing the SDK PUT call: **31 of 40 read attempts intersected the SDK call**, six returning a whole value matching the accepted Generation and 25 safely rejecting. Server commit overlap remains unknown. An earlier preparation-inclusive run is retained as weaker evidence. A release-build receipt connects the launched test binary to 20 files from its Git source commit. Earlier runs that only timed PUT plus post-PUT Lookup, and repeated A/B-byte runs, remain explicitly weaker evidence. Isolated test-only server QP/MR cleanup-error injections each aborted with launch-time hashes; a normal server restart read the same object. [Raw logs and replay auditors](kv-service/verification/results/README.md) are checked in; this is bounded execution evidence rather than a provider or implementation proof.

A separate [Generation-transition witness](docs/paper/generation-transition-witness-2026-10-12.md) observed eight rejected direct reads with strictly increasing pre/post-transfer metadata Generations, proving a metadata transition during each read method under its single-writer setup. The caller buffer remained intact; the exact server commit time and in-flight RDMA WRITE state remain unmeasured. This one-run receipt is kept separate from the two-run campaign above.

---

## Deployment shapes

- **Local dev** — `contextstore-server --config kv-service/configs/server-test.toml`, backed by a local NVMe directory.
- **Docker / Compose** — run `make docker` to build the image, then use
  `kv-service/deploy/docker/docker-compose.yml`; the Docker build includes the
  RDMA, `io-uring`, and metrics feature set.
- **Kubernetes** — three manifests under `kv-service/deploy/k8s/`:
  `statefulset.yaml` (gRPC only), `statefulset-rdma.yaml` (RDMA, hostNetwork),
  and `statefulset-rdma-spiderpool.yaml` (RDMA over a Multus/spiderpool
  secondary NIC with fixed-IP pools and dynamic GID probing — use this when
  client pods reach storage over the same secondary network).
- **Systemd** — `kv-service/deploy/systemd/contextstore-server.service`.
- **JBOF over NVMe-oF** — `kv-service/configs/server-nvmeof.toml` plus the SPDK target and NVMe-oF initiator helpers in `kv-service/deploy/jbof/`. `make build` includes the pre-registered-slab, zero-memcpy RDMA WRITE data path.

See [`kv-service/configs/README.md`](kv-service/configs/README.md) for config
fields and [`kv-service/deploy/README.md`](kv-service/deploy/README.md) for the
exact deployment commands.

---

## Integration paths

| Engine | Connector class | Module path |
|--------|----------------|-------------|
| vLLM | `ContextStoreConnector` | `contextstore.connector` |
| Dynamo (KVBM) | `DynamoConnector` | `contextstore.integrations.dynamo.connector` |
| NIXL | N/A (native plugin) | Build `nixl-plugin/contextstore/` — loads `libcontextstore_nixl_client.so` via `CONTEXTSTORE` backend |

---

## Roadmap

Directions we plan to work on next. This is a feature-level roadmap, not a release schedule; already-shipped capabilities are covered by the Architecture, KVService, Deployment, and Integration sections above.

| Area | Feature | Status | Notes |
|------|---------|--------|-------|
| Connector | Prefix-aware request routing | planned | Surface prefix-hit info back to upstream schedulers so they colocate requests that share a long prefix |
| Prefix Index | Standalone Prefix Index Service | planned | Promote the in-process / Redis index into a dedicated service for cross-instance prefix discovery |
| Prefix Index | Namespace and tenant isolation | planned | First-class model / tenant / namespace isolation, quotas and lifecycle rules |
| KVService | Object lifecycle | in progress | TTL expiry, quota-based rejection, and cross-tier LRU eviction (L1 LRU is already live) |
| Data Path | Raw JBOF block allocator | planned | Skip the filesystem: block allocator + placement policy directly against raw JBOF / NVMe-oF namespaces |
| Data Path | GDS (GPUDirect Storage) | experimental | Explicit `gds` build feature for local GPU IPC and unstriped NVMe objects; striped and cross-node GDS remain future work |
| Codec | Higher-ratio KV codec | planned | INT4, per-layer quantization, and other layouts beyond the current INT8 codec |

Contributions are welcome — please open an issue first to align on scope.

---

## Development conventions

All code and doc changes must follow [`CLAUDE.md`](./CLAUDE.md):

- Python uses PEP 604 typing syntax (`bytes | None`, `list[str]`) with `from __future__ import annotations` at the top of every file; formatted with `black`, linted with `ruff`.
- Rust is formatted with `cargo fmt` and must pass `cargo clippy -- -D warnings`; optional capabilities are gated behind Cargo features.
- Storage access goes through the `StorageBackend` abstraction; hot paths avoid GIL-bound work and logging overhead.
- The repository keeps exactly two top-level documents (`README.md` and `CLAUDE.md`). Do not add a `docs/` tree — put design notes in code comments or PR descriptions.

---

## Origin

Originally created by [DaoCloud](https://github.com/DaoCloud).

---

## License

Apache-2.0. See [LICENSE](./LICENSE).
