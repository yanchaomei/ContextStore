//! Storage Tier (L2) — persistent storage
//!
//! Responsibilities:
//! - Use the router to decide the physical location of a key.
//! - Use io_executor to perform the actual I/O.
//! - Maintain block metadata (via MetadataService).
//! - Auto-stripe large values: values over the threshold are split into chunks distributed across
//!   multiple devices.

use crate::config::Config;
use crate::error::{KVError, Result};
use crate::io_executor::{create_executor, IOExecutor, IORequest};
use crate::metadata::{BlockMeta, MetadataService, StripingInfo};
use crate::metrics::Metrics;
use crate::router::{ObjectKey, ShardRouter};
use dashmap::DashMap;
use parking_lot::Mutex;
use prost::bytes::{Bytes, BytesMut};
use std::hash::Hasher;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Instant;
use tracing::{debug, warn};
use twox_hash::xxh3::{hash64, Hash64 as Xxh3Hash64};

const DIRECT_IO_ALIGNMENT: usize = 4096;

pub struct StorageTier {
    router: Arc<ShardRouter>,
    executor: Arc<dyn IOExecutor>,
    metadata: Arc<MetadataService>,
    write_locks: DashMap<String, Arc<Mutex<()>>>,
    striping_threshold: u64,
    striping_chunk_size: u64,
    rdma_stream_chunk_size: usize,
    verify_stripe_checksums: bool,
    gc_grace_seconds: u64,
    executor_name: String,
    device_labels: Vec<String>,
    metrics: Option<Arc<Metrics>>,

    // ===== Stats (exported to Prometheus) =====
    pub reads_total: AtomicU64,
    pub writes_total: AtomicU64,
    pub bytes_read: AtomicU64,
    pub bytes_written: AtomicU64,
    pub striped_writes: AtomicU64,
    pub device_read_bytes_total: Arc<Vec<AtomicU64>>,
    pub device_used_bytes_total: Arc<Vec<AtomicU64>>,
}

impl StorageTier {
    pub fn new(config: &Config, router: Arc<ShardRouter>) -> Result<Self> {
        Self::new_with_metrics(config, router, None)
    }

    pub fn new_with_metrics(
        config: &Config,
        router: Arc<ShardRouter>,
        metrics: Option<Arc<Metrics>>,
    ) -> Result<Self> {
        let executor = create_executor(config)?;
        let metadata = Arc::new(MetadataService::new_with_metrics(config, metrics.clone())?);
        let num_devices = router.num_devices();
        // Create the root directory for each device.
        let mut device_used_bytes_total = Vec::with_capacity(num_devices);
        for device in router.devices() {
            let root = device.join(&config.storage.data_subdir).join("data");
            std::fs::create_dir_all(&root).ok();
            let used_bytes = metrics
                .as_ref()
                .map(|_| directory_size_bytes(&root))
                .unwrap_or(0);
            device_used_bytes_total.push(AtomicU64::new(used_bytes));
        }
        Ok(Self {
            router,
            executor,
            metadata,
            write_locks: DashMap::new(),
            striping_threshold: config.storage.striping_threshold,
            striping_chunk_size: config.storage.striping_chunk_size.max(1),
            rdma_stream_chunk_size: (config.storage.rdma_stream_chunk_size as usize)
                .max(DIRECT_IO_ALIGNMENT)
                & !(DIRECT_IO_ALIGNMENT - 1),
            verify_stripe_checksums: config.storage.verify_stripe_checksums,
            gc_grace_seconds: config.gc.grace_seconds,
            executor_name: config.io_executor.kind.clone(),
            device_labels: (0..num_devices)
                .map(|device_id| format!("nvme{}", device_id))
                .collect(),
            metrics,
            reads_total: AtomicU64::new(0),
            writes_total: AtomicU64::new(0),
            bytes_read: AtomicU64::new(0),
            bytes_written: AtomicU64::new(0),
            striped_writes: AtomicU64::new(0),
            device_read_bytes_total: Arc::new(
                (0..num_devices).map(|_| AtomicU64::new(0)).collect(),
            ),
            device_used_bytes_total: Arc::new(device_used_bytes_total),
        })
    }

    pub fn metadata(&self) -> Arc<MetadataService> {
        self.metadata.clone()
    }

    pub fn router(&self) -> Arc<ShardRouter> {
        self.router.clone()
    }

    pub fn striping_threshold(&self) -> u64 {
        self.striping_threshold
    }

    pub fn striping_chunk_size(&self) -> u64 {
        self.striping_chunk_size
    }

    /// Whether striped disk reads are protected by persisted per-stripe checksums.
    pub fn verify_stripe_checksums(&self) -> bool {
        self.verify_stripe_checksums
    }

    pub fn device_read_bytes(&self, device_id: usize) -> u64 {
        self.device_read_bytes_total
            .get(device_id)
            .map(|counter| counter.load(Ordering::Relaxed))
            .unwrap_or(0)
    }

    /// Return the configured delay before a retired generation may be reclaimed.
    pub fn gc_grace_seconds(&self) -> u64 {
        self.gc_grace_seconds
    }

    fn gc_not_before(&self) -> i64 {
        chrono::Utc::now().timestamp() + self.gc_grace_seconds as i64
    }

    /// Atomically remove the current metadata and schedule its physical layout
    /// for delayed reclamation. L1 invalidation is owned by the caller.
    pub fn retire(&self, key: &ObjectKey) -> Result<bool> {
        Ok(self
            .metadata
            .retire_block(&key.to_string_key(), self.gc_not_before())?
            .is_some())
    }

    pub fn device_used_bytes(&self, device_id: usize) -> u64 {
        self.device_used_bytes_total
            .get(device_id)
            .map(|counter| counter.load(Ordering::Relaxed))
            .unwrap_or(0)
    }

    fn record_device_read(&self, device_id: usize, bytes: u64) {
        if let Some(counter) = self.device_read_bytes_total.get(device_id) {
            counter.fetch_add(bytes, Ordering::Relaxed);
        }
    }

    fn record_device_write(&self, device_id: usize, bytes: u64) {
        if let Some(counter) = self.device_used_bytes_total.get(device_id) {
            counter.fetch_add(bytes, Ordering::Relaxed);
        }
    }

    fn record_device_delete(&self, device_id: usize, bytes: u64) {
        if let Some(counter) = self.device_used_bytes_total.get(device_id) {
            let _ = counter.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |current| {
                Some(current.saturating_sub(bytes))
            });
        }
    }

    fn device_label(&self, device_id: usize) -> &str {
        self.device_labels
            .get(device_id)
            .map(String::as_str)
            .unwrap_or("unknown")
    }

    fn file_size(path: &Path) -> u64 {
        std::fs::metadata(path).map(|meta| meta.len()).unwrap_or(0)
    }

    fn checksum_bytes(data: &[u8]) -> String {
        format!("{:016x}", hash64(data))
    }

    fn checksum_segments(segments: &[Bytes]) -> String {
        let mut hasher = Xxh3Hash64::default();
        for segment in segments {
            hasher.write(segment);
        }
        format!("{:016x}", hasher.finish())
    }

    fn checksum_ptr(ptr: *const u8, len: usize) -> String {
        // The caller guarantees that this range is valid and initialized by the I/O operation.
        let data = unsafe { std::slice::from_raw_parts(ptr, len) };
        Self::checksum_bytes(data)
    }

    fn expected_stripe_checksum<'a>(
        &self,
        stripe: &'a StripingInfo,
        stripe_index: usize,
    ) -> Result<Option<&'a str>> {
        if !self.verify_stripe_checksums {
            return Ok(None);
        }
        stripe
            .chunk_checksums
            .get(stripe_index)
            .filter(|checksum| !checksum.is_empty())
            .map(String::as_str)
            .map(Some)
            .ok_or_else(|| {
                KVError::NotFound(format!(
                    "striped object has no checksum for stripe {}; rewrite required",
                    stripe_index
                ))
            })
    }

    fn verify_stripe_bytes(
        &self,
        stripe: &StripingInfo,
        stripe_index: usize,
        data: &[u8],
    ) -> Result<()> {
        let Some(expected) = self.expected_stripe_checksum(stripe, stripe_index)? else {
            return Ok(());
        };
        let actual = Self::checksum_bytes(data);
        if actual == expected {
            return Ok(());
        }
        tracing::warn!(
            event = "stripe_integrity_check_failed",
            stripe_index,
            expected_checksum = expected,
            actual_checksum = actual,
            bytes = data.len(),
            "stripe checksum mismatch"
        );
        Err(KVError::NotFound(format!(
            "striped object checksum mismatch for stripe {}",
            stripe_index
        )))
    }

    fn observe_io<T>(
        &self,
        operation: &'static str,
        device_id: usize,
        mode: &'static str,
        bytes: u64,
        work: impl FnOnce() -> Result<T>,
    ) -> Result<T> {
        let Some(metrics) = &self.metrics else {
            return work();
        };
        let device = self.device_label(device_id);
        metrics.storage_io_started(operation, device, &self.executor_name, mode);
        let started = Instant::now();
        let result = work();
        let status = if result.is_ok() { "ok" } else { "error" };
        metrics.record_storage_io(
            operation,
            device,
            &self.executor_name,
            mode,
            status,
            bytes,
            started.elapsed().as_secs_f64(),
        );
        if result.is_err() {
            metrics.record_storage_io_error(
                operation,
                device,
                &self.executor_name,
                mode,
                "io_error",
            );
        }
        result
    }

    fn write_file_on_device(&self, device_id: usize, path: &Path, data: &[u8]) -> Result<()> {
        let bytes = data.len() as u64;
        let result = self.observe_io("write", device_id, "buffered", bytes, || {
            self.executor.write_file(path, data)
        });
        if result.is_ok() {
            self.record_device_write(device_id, Self::file_size(path));
        }
        result
    }

    fn read_file_on_device(&self, device_id: usize, path: &Path) -> Result<Vec<u8>> {
        let result = self.observe_io("read", device_id, "buffered", 0, || {
            self.executor.read_file(path)
        });
        if let Ok(data) = &result {
            if let Some(metrics) = &self.metrics {
                metrics.record_storage_io_bytes(
                    "read",
                    self.device_label(device_id),
                    &self.executor_name,
                    "buffered",
                    data.len() as u64,
                );
            }
        }
        result
    }

    fn delete_file_on_device(&self, device_id: usize, path: &Path) -> Result<()> {
        let bytes = Self::file_size(path);
        let result = self.observe_io("delete", device_id, "buffered", bytes, || {
            self.executor.delete_file(path)
        });
        if result.is_ok() {
            self.record_device_delete(device_id, bytes);
        }
        result
    }

    fn observe_io_batch<T>(
        &self,
        operation: &'static str,
        mode: &'static str,
        device_ids: &[usize],
        bytes: &[u64],
        work: impl FnOnce() -> Vec<Result<T>>,
    ) -> Vec<Result<T>> {
        let Some(metrics) = &self.metrics else {
            return work();
        };
        for device_id in device_ids {
            metrics.storage_io_started(
                operation,
                self.device_label(*device_id),
                &self.executor_name,
                mode,
            );
        }
        let started = Instant::now();
        let results = work();
        let duration_seconds = started.elapsed().as_secs_f64();
        for (index, device_id) in device_ids.iter().enumerate() {
            let device = self.device_label(*device_id);
            let result = results.get(index);
            let status = match result {
                Some(Ok(_)) => "ok",
                Some(Err(_)) => "error",
                None => "incomplete",
            };
            metrics.record_storage_io(
                operation,
                device,
                &self.executor_name,
                mode,
                status,
                if matches!(result, Some(Ok(_))) {
                    bytes.get(index).copied().unwrap_or(0)
                } else {
                    0
                },
                duration_seconds,
            );
            if !matches!(result, Some(Ok(_))) {
                metrics.record_storage_io_error(
                    operation,
                    device,
                    &self.executor_name,
                    mode,
                    if result.is_some() {
                        "io_error"
                    } else {
                        "incomplete_result"
                    },
                );
            }
        }
        results
    }

    fn device_id_for_path(&self, path: &Path) -> Option<usize> {
        self.router
            .devices()
            .iter()
            .enumerate()
            .filter(|(_, device)| path.starts_with(device))
            .max_by_key(|(_, device)| device.components().count())
            .map(|(device_id, _)| device_id)
    }

    fn meta_path_or_route(&self, key: &ObjectKey, meta: &BlockMeta) -> PathBuf {
        if meta.file_path.is_empty() {
            self.router.key_to_path(key)
        } else {
            PathBuf::from(&meta.file_path)
        }
    }

    fn meta_device_or_route(&self, key: &ObjectKey, meta: &BlockMeta) -> usize {
        let device_id = meta.device_id as usize;
        if device_id < self.router.num_devices() {
            device_id
        } else {
            self.router.route(key)
        }
    }

    fn delete_paths_best_effort(&self, paths: &[PathBuf]) {
        for path in paths {
            if let Some(device_id) = self.device_id_for_path(path) {
                let _ = self.delete_file_on_device(device_id, path);
            } else {
                let _ = self.executor.delete_file(path);
            }
        }
    }

    fn meta_identity_matches(actual: &BlockMeta, expected: &BlockMeta) -> bool {
        actual.object_handle == expected.object_handle
            && actual.object_generation == expected.object_generation
            && actual.layout_version == expected.layout_version
            && actual.content_etag == expected.content_etag
            && actual.size == expected.size
    }

    #[cfg(test)]
    fn delete_files_for_meta(&self, key: &ObjectKey, meta: &BlockMeta) -> Result<()> {
        if let Some(stripe) = &meta.striping {
            let mut last_err = None;
            for (index, path) in stripe.chunk_paths.iter().enumerate() {
                let Some(device_id) = stripe
                    .chunk_devices
                    .get(index)
                    .copied()
                    .map(|device_id| device_id as usize)
                    .or_else(|| self.device_id_for_path(Path::new(path)))
                else {
                    last_err = Some(KVError::InvalidArgument(format!(
                        "unable to identify storage device for {}",
                        path
                    )));
                    continue;
                };
                if let Err(e) = self.delete_file_on_device(device_id, Path::new(path)) {
                    last_err = Some(e);
                }
            }
            if let Some(e) = last_err {
                return Err(e);
            }
        } else {
            let path = self.meta_path_or_route(key, meta);
            self.delete_file_on_device(self.meta_device_or_route(key, meta), &path)?;
        }
        Ok(())
    }

    fn delete_metadata_if_current(&self, key: &ObjectKey, meta: &BlockMeta) -> Result<bool> {
        self.metadata
            .delete_block_if_matches(&key.to_string_key(), meta)
    }

    fn commit_metadata_with_rollback(
        &self,
        key: &ObjectKey,
        meta: &BlockMeta,
        new_paths: &[PathBuf],
        if_absent: bool,
    ) -> Result<bool> {
        let str_key = key.to_string_key();
        let result = if if_absent {
            self.metadata.put_block_if_absent(&str_key, meta)
        } else {
            self.metadata
                .replace_block(&str_key, meta, self.gc_not_before())
                .map(|_| true)
        };
        match result {
            Ok(true) => Ok(true),
            Ok(false) => {
                self.delete_paths_best_effort(new_paths);
                Ok(false)
            }
            Err(e) => {
                self.delete_paths_best_effort(new_paths);
                Err(e)
            }
        }
    }

    fn stripe_files_exist(&self, stripe: &StripingInfo) -> bool {
        stripe
            .chunk_paths
            .iter()
            .all(|path| self.executor.file_exists(std::path::Path::new(path)))
    }

    fn is_not_found_error(error: &KVError) -> bool {
        match error {
            KVError::NotFound(_) => true,
            KVError::Io(err) => err.kind() == std::io::ErrorKind::NotFound,
            _ => false,
        }
    }

    fn delete_expired_current_locked(&self, key: &ObjectKey, expected: &BlockMeta) -> Result<bool> {
        let str_key = key.to_string_key();
        let Some(current) = self.metadata.get_block(&str_key)? else {
            return Ok(false);
        };
        if !current.is_expired() || !Self::meta_identity_matches(&current, expected) {
            return Ok(false);
        }
        self.metadata
            .retire_block_if_matches(&str_key, &current, self.gc_not_before())
    }

    fn purge_if_expired(&self, key: &ObjectKey, meta: &BlockMeta) -> Result<bool> {
        if !meta.is_expired() {
            return Ok(false);
        }
        let write_lock = self.key_write_lock(key);
        let _guard = write_lock.lock();
        self.delete_expired_current_locked(key, meta)
    }

    /// Delete the object only when metadata still points to the same expired object identity.
    pub fn delete_if_expired(&self, key: &ObjectKey, meta: &BlockMeta) -> Result<bool> {
        self.purge_if_expired(key, meta)
    }

    fn content_etag(key: &ObjectKey, generation: u64, size: u64, created_at: i64) -> String {
        let seed = format!(
            "{}|generation={}|size={}|created_at={}",
            key.to_string_key(),
            generation,
            size,
            created_at
        );
        format!("{:016x}", hash64(seed.as_bytes()))
    }

    fn object_handle(
        key: &ObjectKey,
        generation: u64,
        layout_version: u64,
        size: u64,
        created_at: i64,
    ) -> String {
        let seed = format!(
            "{}|generation={}|layout={}|size={}|created_at={}",
            key.to_string_key(),
            generation,
            layout_version,
            size,
            created_at
        );
        format!(
            "ctxobj-v1-{}-g{}-l{}-{:016x}",
            key.object_digest(),
            generation,
            layout_version,
            hash64(seed.as_bytes())
        )
    }

    fn key_write_lock(&self, key: &ObjectKey) -> Arc<Mutex<()>> {
        let str_key = key.to_string_key();
        self.write_locks
            .entry(str_key)
            .or_insert_with(|| Arc::new(Mutex::new(())))
            .clone()
    }

    pub fn prepare_write_meta(
        &self,
        key: &ObjectKey,
        mut meta: BlockMeta,
        size: u64,
    ) -> Result<BlockMeta> {
        let generation = self.metadata.next_generation(&key.to_string_key())?;
        let layout_version = 1;
        meta.size = size;
        meta.object_generation = generation;
        meta.layout_version = layout_version;
        meta.object_handle =
            Self::object_handle(key, generation, layout_version, size, meta.created_at);
        meta.content_etag = Self::content_etag(key, generation, meta.size, meta.created_at);
        Ok(meta)
    }

    fn ensure_managed_path(&self, path: &std::path::Path) -> Result<()> {
        let managed = self
            .router
            .devices()
            .iter()
            .any(|device| path.starts_with(device));
        if !managed {
            return Err(KVError::InvalidArgument(format!(
                "storage_handle outside managed devices: {}",
                path.display()
            )));
        }
        Ok(())
    }

    /// Data-node internal API: write an object stripe with a determined generation/layout.
    pub fn put_placement_chunk(
        &self,
        key: &ObjectKey,
        stripe_index: usize,
        device_stripe_index: usize,
        generation: u64,
        layout_version: u64,
        data: Bytes,
    ) -> Result<(u32, String, String)> {
        let device_id = self.router.chunk_device(key, device_stripe_index);
        let path = self.router.chunk_versioned_path(
            key,
            stripe_index,
            device_id,
            generation,
            layout_version,
        );
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        let checksum = self
            .verify_stripe_checksums
            .then(|| Self::checksum_bytes(&data))
            .unwrap_or_default();
        self.write_file_on_device(device_id, &path, &data)?;
        self.writes_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_written
            .fetch_add(data.len() as u64, Ordering::Relaxed);
        Ok((
            device_id as u32,
            path.to_string_lossy().to_string(),
            checksum,
        ))
    }

    /// Data-node internal API: write an object stripe from multiple `Bytes` segments without
    /// flattening. Used by the streaming PUT pipeline — a stripe accumulated as N gRPC chunk
    /// segments is handed to `write_batch_vectored` (writev fast path on tier_a) directly, so no
    /// 64MB intermediate concat buffer is ever allocated.
    pub fn put_placement_chunk_segments(
        &self,
        key: &ObjectKey,
        stripe_index: usize,
        device_stripe_index: usize,
        generation: u64,
        layout_version: u64,
        segments: Vec<Bytes>,
    ) -> Result<(u32, String, String)> {
        let device_id = self.router.chunk_device(key, device_stripe_index);
        let path = self.router.chunk_versioned_path(
            key,
            stripe_index,
            device_id,
            generation,
            layout_version,
        );
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        let checksum = self
            .verify_stripe_checksums
            .then(|| Self::checksum_segments(&segments))
            .unwrap_or_default();
        let total: usize = segments.iter().map(|s| s.len()).sum();
        let req = IORequest {
            path: path.clone(),
            offset: 0,
            length: total,
        };
        let results = self.executor.write_batch_vectored(vec![(req, segments)]);
        results.into_iter().next().unwrap_or_else(|| {
            Err(KVError::Internal(
                "write_batch_vectored empty result".into(),
            ))
        })?;
        self.writes_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_written
            .fetch_add(total as u64, Ordering::Relaxed);
        Ok((
            device_id as u32,
            path.to_string_lossy().to_string(),
            checksum,
        ))
    }

    /// Validate that a placement chunk handle matches the descriptor identity and router layout.
    pub fn validate_placement_chunk_handle(
        &self,
        key: &ObjectKey,
        stripe_index: usize,
        generation: u64,
        layout_version: u64,
        device_id: u32,
        storage_handle: &str,
    ) -> Result<()> {
        let path = PathBuf::from(storage_handle);
        self.ensure_managed_path(&path)?;
        let device_id = device_id as usize;
        if device_id >= self.router.num_devices() {
            return Err(KVError::InvalidArgument(format!(
                "placement chunk device out of range: {}",
                device_id
            )));
        }
        let expected = self.router.chunk_versioned_path(
            key,
            stripe_index,
            device_id,
            generation,
            layout_version,
        );
        if path != expected {
            return Err(KVError::InvalidArgument(format!(
                "placement chunk handle does not match descriptor: {}",
                path.display()
            )));
        }
        Ok(())
    }

    /// Data-node internal API: read a placement chunk by a server-generated storage handle.
    ///
    /// `expected_checksum` is present only for striped objects. A non-striped placement chunk
    /// intentionally skips the optional stripe-integrity check.
    pub fn read_placement_chunk(
        &self,
        storage_handle: &str,
        expected_len: u64,
        expected_checksum: Option<&str>,
    ) -> Result<Option<Bytes>> {
        let path = PathBuf::from(storage_handle);
        self.ensure_managed_path(&path)?;
        if !self.executor.file_exists(&path) {
            return Ok(None);
        }
        let device_id = self.device_id_for_path(&path).ok_or_else(|| {
            KVError::InvalidArgument(format!(
                "unable to identify storage device for {}",
                path.display()
            ))
        })?;
        let data = self.read_file_on_device(device_id, &path)?;
        if expected_len > 0 && data.len() as u64 != expected_len {
            return Err(KVError::Internal(format!(
                "placement chunk length mismatch: expected {} got {} ({})",
                expected_len,
                data.len(),
                path.display()
            )));
        }
        if self.verify_stripe_checksums {
            if let Some(expected_checksum) = expected_checksum {
                if expected_checksum.is_empty() {
                    return Err(KVError::NotFound(
                        "placement chunk has no checksum; rewrite required".to_string(),
                    ));
                }
                let actual = Self::checksum_bytes(&data);
                if actual != expected_checksum {
                    tracing::warn!(
                        event = "stripe_integrity_check_failed",
                        expected_checksum,
                        actual_checksum = actual,
                        bytes = data.len(),
                        path = %path.display(),
                        "placement chunk checksum mismatch"
                    );
                    return Err(KVError::NotFound(
                        "placement chunk checksum mismatch".to_string(),
                    ));
                }
            }
        }
        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read
            .fetch_add(data.len() as u64, Ordering::Relaxed);
        Ok(Some(Bytes::from(data)))
    }

    /// Data-node internal API: delete a placement chunk, used for object deletion or write-failure
    /// rollback.
    pub fn delete_placement_chunk(&self, storage_handle: &str) -> Result<bool> {
        let path = PathBuf::from(storage_handle);
        self.ensure_managed_path(&path)?;
        let existed = self.executor.file_exists(&path);
        let device_id = self.device_id_for_path(&path).ok_or_else(|| {
            KVError::InvalidArgument(format!(
                "unable to identify storage device for {}",
                path.display()
            ))
        })?;
        self.delete_file_on_device(device_id, &path)?;
        Ok(existed)
    }

    /// Whether a value should be striped.
    fn should_stripe(&self, len: usize) -> bool {
        self.striping_threshold > 0
            && (len as u64) > self.striping_threshold
            && self.router.num_devices() > 1
    }

    // ===== Single-entry =====

    pub fn get(&self, key: &ObjectKey) -> Result<Option<(Bytes, BlockMeta)>> {
        let str_key = key.to_string_key();
        let meta = match self.metadata.get_block(&str_key)? {
            Some(m) => m,
            None => return Ok(None),
        };
        if self.purge_if_expired(key, &meta)? {
            return Ok(None);
        }

        // Striped path: read all chunks in parallel and concat.
        if let Some(stripe) = &meta.striping {
            let data = match self.read_striped(key, stripe) {
                Ok(data) => data,
                Err(KVError::NotFound(_)) => {
                    self.delete_metadata_if_current(key, &meta)?;
                    return Ok(None);
                }
                Err(e) => return Err(e),
            };
            self.reads_total.fetch_add(1, Ordering::Relaxed);
            self.bytes_read
                .fetch_add(data.len() as u64, Ordering::Relaxed);
            return Ok(Some((Bytes::from(data), meta)));
        }

        let path = self.meta_path_or_route(key, &meta);
        if !self.executor.file_exists(&path) {
            self.delete_metadata_if_current(key, &meta)?;
            return Ok(None);
        }
        debug!("L2 GET {} -> {}", str_key, path.display());
        let data = self.read_file_on_device(self.meta_device_or_route(key, &meta), &path)?;
        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read
            .fetch_add(data.len() as u64, Ordering::Relaxed);
        self.record_device_read(self.meta_device_or_route(key, &meta), data.len() as u64);
        // Vec<u8> → Bytes is a zero-copy handoff (Bytes::from takes over the Vec's allocation).
        Ok(Some((Bytes::from(data), meta)))
    }

    pub fn put(&self, key: &ObjectKey, data: Bytes, meta: BlockMeta) -> Result<()> {
        let write_lock = self.key_write_lock(key);
        let _guard = write_lock.lock();

        if self.should_stripe(data.len()) {
            return self.put_striped(key, data, meta);
        }

        let mut meta = self.prepare_write_meta(key, meta, data.len() as u64)?;
        let device_id = self.router.route(key);
        let path = self.router.key_to_versioned_path(
            key,
            device_id,
            meta.object_generation,
            meta.layout_version,
        );
        // Ensure the parent directory exists.
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        debug!(
            "L2 PUT {} -> {} ({} bytes)",
            key.to_string_key(),
            path.display(),
            data.len()
        );
        let nbytes = data.len();
        // Non-striping single path: write_file takes &[u8]; data is only borrowed here, no copy.
        self.write_file_on_device(device_id, &path, &data)?;
        meta.file_path = path.to_string_lossy().to_string();
        meta.size = nbytes as u64;
        meta.device_id = device_id as u32;
        meta.striping = None;
        self.commit_metadata_with_rollback(key, &meta, std::slice::from_ref(&path), false)?;
        self.writes_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_written
            .fetch_add(nbytes as u64, Ordering::Relaxed);
        Ok(())
    }

    /// PUT-if-absent: check metadata and write under the same per-key lock.
    pub fn put_if_absent(&self, key: &ObjectKey, data: Bytes, meta: BlockMeta) -> Result<bool> {
        let write_lock = self.key_write_lock(key);
        let _guard = write_lock.lock();

        if let Some(existing) = self.metadata.get_block(&key.to_string_key())? {
            if !existing.is_expired() {
                return Ok(false);
            }
            self.delete_expired_current_locked(key, &existing)?;
        }
        if self.should_stripe(data.len()) {
            let total = data.len();
            return self.put_striped_chunks_impl(key, vec![data], total, meta, true);
        }

        let mut meta = self.prepare_write_meta(key, meta, data.len() as u64)?;
        let device_id = self.router.route(key);
        let path = self.router.key_to_versioned_path(
            key,
            device_id,
            meta.object_generation,
            meta.layout_version,
        );
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        let nbytes = data.len();
        self.write_file_on_device(device_id, &path, &data)?;
        meta.file_path = path.to_string_lossy().to_string();
        meta.size = nbytes as u64;
        meta.device_id = device_id as u32;
        meta.striping = None;
        if !self.commit_metadata_with_rollback(key, &meta, std::slice::from_ref(&path), true)? {
            return Ok(false);
        }
        self.writes_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_written
            .fetch_add(nbytes as u64, Ordering::Relaxed);
        Ok(true)
    }

    /// Multi-segment PUT — zero-copy passthrough: caller supplies a set of `Bytes` (typical: 240 2MB
    /// chunks accumulated by put_stream). On the striping path, segments are rebucketed on
    /// `striping_chunk_size` boundaries into N groups, each `writev`'d to a single disk file in one
    /// syscall. **Never concatenated into a single large Bytes**, so we avoid the 480MB anonymous
    /// mmap first-touch (~780ms page-fault write).
    ///
    /// Small values that skip striping: fall back to concatenating a single copy here (they are
    /// small, so the copy is negligible).
    pub fn put_chunks(&self, key: &ObjectKey, segments: Vec<Bytes>, meta: BlockMeta) -> Result<()> {
        let total: usize = segments.iter().map(|s| s.len()).sum();
        if !self.should_stripe(total) {
            // Small value: concat and take the old path (copy overhead is negligible).
            let mut buf = BytesMut::with_capacity(total);
            for s in &segments {
                buf.extend_from_slice(s);
            }
            return self.put(key, buf.freeze(), meta);
        }
        let write_lock = self.key_write_lock(key);
        let _guard = write_lock.lock();
        self.put_striped_chunks(key, segments, total, meta)
    }

    /// Multi-segment PUT-if-absent. The existence check and write share one per-key lock, so
    /// concurrent stream writes for the same object cannot overwrite each other.
    pub fn put_chunks_if_absent(
        &self,
        key: &ObjectKey,
        segments: Vec<Bytes>,
        meta: BlockMeta,
    ) -> Result<bool> {
        let total: usize = segments.iter().map(|s| s.len()).sum();
        if !self.should_stripe(total) {
            let mut buf = BytesMut::with_capacity(total);
            for s in &segments {
                buf.extend_from_slice(s);
            }
            return self.put_if_absent(key, buf.freeze(), meta);
        }
        let write_lock = self.key_write_lock(key);
        let _guard = write_lock.lock();
        if let Some(existing) = self.metadata.get_block(&key.to_string_key())? {
            if !existing.is_expired() {
                return Ok(false);
            }
            self.delete_expired_current_locked(key, &existing)?;
        }
        self.put_striped_chunks_impl(key, segments, total, meta, true)
    }

    /// **RDMA PUT data-plane only** — data is already in caller-pinned 4K-aligned memory (an RDMA
    /// slab extent). Directly O_DIRECT pwrite N stripes across N NVMes, **zero memcpy, zero concat**.
    ///
    /// Key difference vs put_chunks: put_chunks goes through write_vec_impl which internally memcpy's
    /// 240 segments into a thread_local AlignedBuffer (138–255ms/64MB bug) and then pwrites.
    /// put_from_ptr skips memcpy entirely; ptr is the pwrite source (slab is already 4K-aligned +
    /// pinned).
    ///
    /// Parameters:
    /// - ptr: 4K-aligned start address (slab extent base)
    /// - total: valid data length in bytes
    /// - meta: BlockMeta (file_path / size / device_id are overwritten by this fn)
    ///
    /// # Safety
    /// The caller must guarantee:
    /// - ptr..ptr+total is not freed / mutated before every worker's pwrite completes.
    /// - ptr is 4K-aligned (slab.alloc already guarantees this).
    /// - total > 0 (empty values should not reach here; they should take the put path).
    ///
    /// Small values that skip striping: they still take the striped path here (the RDMA PUT is
    /// designed for large values; small values are faster on the gRPC path anyway).
    pub fn put_from_ptr(
        &self,
        key: &ObjectKey,
        ptr: *const u8,
        total: usize,
        meta: BlockMeta,
    ) -> Result<()> {
        self.put_from_ptr_with_options(key, ptr, total, meta, false)
            .map(|_| ())
    }

    /// RDMA PUT-if-absent variant. The metadata existence check and the
    /// physical write are protected by the same per-key lock used by gRPC PUT.
    /// A cross-node metadata race is resolved by Redis `SET NX`; loser files
    /// are removed before returning `false`.
    pub fn put_from_ptr_if_absent(
        &self,
        key: &ObjectKey,
        ptr: *const u8,
        total: usize,
        meta: BlockMeta,
    ) -> Result<bool> {
        self.put_from_ptr_with_options(key, ptr, total, meta, true)
    }

    fn put_from_ptr_with_options(
        &self,
        key: &ObjectKey,
        ptr: *const u8,
        total: usize,
        meta: BlockMeta,
        if_not_exists: bool,
    ) -> Result<bool> {
        if total == 0 {
            return Err(KVError::Internal("put_from_ptr: empty data".into()));
        }
        let write_lock = self.key_write_lock(key);
        let _guard = write_lock.lock();
        if if_not_exists {
            if let Some(existing) = self.metadata.get_block(&key.to_string_key())? {
                if !existing.is_expired() {
                    return Ok(false);
                }
                self.delete_expired_current_locked(key, &existing)?;
            }
        }
        // The RDMA PUT path only serves large values; small values never take this route. But as a
        // fallback: no stripe → single-file pwrite (via write_aligned_batch with one item).
        if !self.should_stripe(total) {
            let mut meta = self.prepare_write_meta(key, meta, total as u64)?;
            let device_id = self.router.route(key);
            let path = self.router.key_to_versioned_path(
                key,
                device_id,
                meta.object_generation,
                meta.layout_version,
            );
            if let Some(parent) = path.parent() {
                std::fs::create_dir_all(parent).ok();
            }
            let req = IORequest {
                path: path.clone(),
                offset: 0,
                length: total,
            };
            let results =
                self.observe_io_batch("write", "aligned", &[device_id], &[total as u64], || {
                    self.executor.write_aligned_batch(vec![(req, ptr, total)])
                });
            results.into_iter().next().unwrap_or_else(|| {
                Err(KVError::Internal("write_aligned_batch empty result".into()))
            })?;
            self.record_device_write(device_id, Self::file_size(&path));
            meta.file_path = path.to_string_lossy().to_string();
            meta.size = total as u64;
            meta.device_id = device_id as u32;
            meta.striping = None;
            let committed = self.commit_metadata_with_rollback(
                key,
                &meta,
                std::slice::from_ref(&path),
                if_not_exists,
            )?;
            if !committed {
                return Ok(false);
            }
            self.writes_total.fetch_add(1, Ordering::Relaxed);
            self.bytes_written
                .fetch_add(total as u64, Ordering::Relaxed);
            return Ok(true);
        }
        self.put_from_ptr_striped(key, ptr, total, meta, if_not_exists)
    }

    /// Internal: put_from_ptr implementation for the striping path.
    ///
    /// Key point: ptr[stripe_idx * chunk_size .. (stripe_idx+1) * chunk_size] is directly the pwrite
    /// source for that stripe; no memory split is needed. 8 stripes → 8 workers each pwrite
    /// (writes_aligned_batch is internally parallel).
    fn put_from_ptr_striped(
        &self,
        key: &ObjectKey,
        ptr: *const u8,
        total: usize,
        meta: BlockMeta,
        if_not_exists: bool,
    ) -> Result<bool> {
        let mut meta = self.prepare_write_meta(key, meta, total as u64)?;
        let chunk_size = self.striping_chunk_size as usize;
        let n_stripes = total.div_ceil(chunk_size);

        let mut chunk_devices: Vec<u32> = Vec::with_capacity(n_stripes);
        let mut chunk_paths: Vec<String> = Vec::with_capacity(n_stripes);
        let mut chunk_checksums: Vec<String> = Vec::with_capacity(n_stripes);
        let mut io_items: Vec<(IORequest, *const u8, usize)> = Vec::with_capacity(n_stripes);

        for i in 0..n_stripes {
            let stripe_start = i * chunk_size;
            let stripe_end = (stripe_start + chunk_size).min(total);
            let stripe_len = stripe_end - stripe_start;
            let dev_id = self.router.chunk_device(key, i);
            let path = self.router.chunk_versioned_path(
                key,
                i,
                dev_id,
                meta.object_generation,
                meta.layout_version,
            );
            // Ensure the parent directory exists (subdirectories may not exist on the first PUT for a
            // new namespace/object).
            if let Some(parent) = path.parent() {
                std::fs::create_dir_all(parent).ok();
            }
            chunk_devices.push(dev_id as u32);
            chunk_paths.push(path.to_string_lossy().to_string());
            // Key point: slab ptr + offset, no memory copy. SLAB_ALIGN=4096 guarantees sub-segments
            // are also 4K-aligned (chunk_size default 64MB is an integer multiple of 4K).
            let stripe_ptr = unsafe { ptr.add(stripe_start) };
            if self.verify_stripe_checksums {
                chunk_checksums.push(Self::checksum_ptr(stripe_ptr, stripe_len));
            }
            io_items.push((
                IORequest {
                    path,
                    offset: 0,
                    length: stripe_len,
                },
                stripe_ptr,
                stripe_len,
            ));
        }

        debug!(
            "L2 PUT striped(ptr) {} -> {} stripes ({} bytes total) ZERO-COPY",
            key.to_string_key(),
            n_stripes,
            total
        );

        let device_ids = chunk_devices
            .iter()
            .map(|id| *id as usize)
            .collect::<Vec<_>>();
        let write_bytes = io_items
            .iter()
            .map(|(request, _, length)| {
                debug_assert_eq!(request.length, *length);
                *length as u64
            })
            .collect::<Vec<_>>();
        let results = self.observe_io_batch("write", "aligned", &device_ids, &write_bytes, || {
            self.executor.write_aligned_batch(io_items)
        });
        for (i, r) in results.into_iter().enumerate() {
            if let Err(e) = r {
                // Roll back the stripe files already written.
                for path in &chunk_paths[..i] {
                    let _ = self.executor.delete_file(std::path::Path::new(path));
                }
                return Err(e);
            }
            self.record_device_write(device_ids[i], Self::file_size(Path::new(&chunk_paths[i])));
        }

        meta.size = total as u64;
        meta.device_id = chunk_devices[0];
        meta.file_path = String::new();
        meta.striping = Some(StripingInfo {
            chunk_size: self.striping_chunk_size,
            chunk_devices,
            chunk_paths,
            total_size: total as u64,
            chunk_locations: Vec::new(),
            chunk_checksums,
        });
        let new_paths = meta
            .striping
            .as_ref()
            .map(|stripe| {
                stripe
                    .chunk_paths
                    .iter()
                    .map(PathBuf::from)
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        let committed =
            self.commit_metadata_with_rollback(key, &meta, &new_paths, if_not_exists)?;
        if !committed {
            return Ok(false);
        }
        self.writes_total.fetch_add(1, Ordering::Relaxed);
        self.striped_writes.fetch_add(1, Ordering::Relaxed);
        self.bytes_written
            .fetch_add(total as u64, Ordering::Relaxed);
        Ok(true)
    }

    pub fn delete(&self, key: &ObjectKey) -> Result<bool> {
        self.retire(key)
    }

    pub fn exists(&self, key: &ObjectKey) -> Result<bool> {
        let Some(meta) = self.metadata.get_block(&key.to_string_key())? else {
            return Ok(false);
        };
        if meta.is_expired() {
            if let Err(error) = self.purge_if_expired(key, &meta) {
                warn!(key = %key.to_string_key(), error = %error, "failed to purge expired object");
            }
            return Ok(false);
        }
        if let Some(stripe) = &meta.striping {
            if self.stripe_files_exist(stripe) {
                return Ok(true);
            }
            self.delete_metadata_if_current(key, &meta)?;
            return Ok(false);
        }
        let path = self.meta_path_or_route(key, &meta);
        if self.executor.file_exists(&path) {
            return Ok(true);
        }
        self.delete_metadata_if_current(key, &meta)?;
        Ok(false)
    }

    // ===== GDS direct read/write (zero-copy) =====
    // Striping and compression are not supported on this path yet; callers should check should_stripe
    // and return an error early.
    #[cfg(feature = "gds")]
    pub fn get_to_gpu(
        &self,
        key: &ObjectKey,
        gpu_buf: &mut crate::gds::GpuBuffer,
    ) -> Result<Option<(usize, BlockMeta)>> {
        let str_key = key.to_string_key();
        let meta = match self.metadata.get_block(&str_key)? {
            Some(m) => m,
            None => return Ok(None),
        };
        if self.purge_if_expired(key, &meta)? {
            return Ok(None);
        }
        if meta.striping.is_some() {
            return Err(crate::error::KVError::InvalidArgument(
                "GDS path does not support striped values yet (TODO: multi-chunk DMA)".into(),
            ));
        }
        let path = self.meta_path_or_route(key, &meta);
        if !self.executor.file_exists(&path) {
            self.delete_metadata_if_current(key, &meta)?;
            return Ok(None);
        }
        let size = meta.size as usize;
        let device_id = self.meta_device_or_route(key, &meta);
        let n = self.observe_io("read", device_id, "gds", 0, || {
            self.executor.read_to_gpu(&path, 0, gpu_buf, size)
        })?;
        if let Some(metrics) = &self.metrics {
            metrics.record_storage_io_bytes(
                "read",
                self.device_label(device_id),
                &self.executor_name,
                "gds",
                n as u64,
            );
        }
        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read.fetch_add(n as u64, Ordering::Relaxed);
        self.record_device_read(device_id, n as u64);
        Ok(Some((n, meta)))
    }

    #[cfg(feature = "gds")]
    pub fn put_from_gpu(
        &self,
        key: &ObjectKey,
        gpu_buf: &crate::gds::GpuBuffer,
        size: usize,
        meta: BlockMeta,
    ) -> Result<()> {
        let write_lock = self.key_write_lock(key);
        let _guard = write_lock.lock();

        if self.should_stripe(size) {
            return Err(crate::error::KVError::InvalidArgument(
                "GDS path does not support striped values yet".into(),
            ));
        }
        let mut meta = self.prepare_write_meta(key, meta, size as u64)?;
        let device_id = self.router.route(key);
        let path = self.router.key_to_versioned_path(
            key,
            device_id,
            meta.object_generation,
            meta.layout_version,
        );
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        let n = self.observe_io("write", device_id, "gds", 0, || {
            self.executor.write_from_gpu(&path, 0, gpu_buf, size)
        })?;
        if let Some(metrics) = &self.metrics {
            metrics.record_storage_io_bytes(
                "write",
                self.device_label(device_id),
                &self.executor_name,
                "gds",
                n as u64,
            );
        }
        meta.size = n as u64;
        meta.file_path = path.to_string_lossy().to_string();
        meta.device_id = device_id as u32;
        self.commit_metadata_with_rollback(key, &meta, std::slice::from_ref(&path), false)?;
        self.writes_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_written.fetch_add(n as u64, Ordering::Relaxed);
        self.record_device_write(device_id, Self::file_size(&path));
        Ok(())
    }

    // ===== Striping path =====

    fn put_striped(&self, key: &ObjectKey, data: Bytes, meta: BlockMeta) -> Result<()> {
        let total = data.len();
        let chunk_size = self.striping_chunk_size as usize;
        let n = (total + chunk_size - 1) / chunk_size;

        // Slice the single Bytes into n Bytes (Arc refcount, zero-copy), then reuse put_striped_chunks.
        let mut segments: Vec<Bytes> = Vec::with_capacity(n);
        for i in 0..n {
            let start = i * chunk_size;
            let end = (start + chunk_size).min(total);
            segments.push(data.slice(start..end));
        }
        // Each segment is already a complete stripe; the rebucketing inside put_striped_chunks
        // degenerates to identity here (each segment length == chunk_size).
        self.put_striped_chunks(key, segments, total, meta)
    }

    /// Multi-segment stripe write — rebucket segments on `chunk_size` boundaries into N stripes,
    /// each stripe writev-ing multiple Bytes in one syscall (zero concat, zero copy).
    ///
    /// Key point: when caller-supplied segments (typical: 240 2MB chunks) cross a stripe boundary,
    /// use `Bytes::slice` to split it in two (refcount, no copy) and assign each half to the adjacent
    /// two stripes.
    fn put_striped_chunks(
        &self,
        key: &ObjectKey,
        segments: Vec<Bytes>,
        total: usize,
        meta: BlockMeta,
    ) -> Result<()> {
        self.put_striped_chunks_impl(key, segments, total, meta, false)
            .map(|_| ())
    }

    fn put_striped_chunks_impl(
        &self,
        key: &ObjectKey,
        segments: Vec<Bytes>,
        total: usize,
        meta: BlockMeta,
        if_absent: bool,
    ) -> Result<bool> {
        let mut meta = self.prepare_write_meta(key, meta, total as u64)?;
        let chunk_size = self.striping_chunk_size as usize;
        let n_stripes = (total + chunk_size - 1) / chunk_size;

        let mut chunk_devices: Vec<u32> = Vec::with_capacity(n_stripes);
        let mut chunk_paths: Vec<String> = Vec::with_capacity(n_stripes);
        let mut chunk_checksums: Vec<String> = Vec::with_capacity(n_stripes);

        // Rebucket segments on chunk_size boundaries: each stripe = Vec<Bytes>.
        // Time complexity O(segments + stripes); only Bytes::slice (Arc bump), no large buffer
        // allocation.
        let mut stripes: Vec<Vec<Bytes>> = (0..n_stripes).map(|_| Vec::new()).collect();
        let mut cur_segment = 0usize;
        let mut cur_offset = 0usize; // Bytes already consumed within the current segment.
        for stripe_idx in 0..n_stripes {
            let stripe_start = stripe_idx * chunk_size;
            let stripe_end = (stripe_start + chunk_size).min(total);
            let mut filled = stripe_start;
            while filled < stripe_end && cur_segment < segments.len() {
                let seg = &segments[cur_segment];
                let seg_remaining = seg.len() - cur_offset;
                let stripe_need = stripe_end - filled;
                let take = seg_remaining.min(stripe_need);
                if take == seg.len() && cur_offset == 0 {
                    // Whole segment belongs to this stripe (zero-copy, just clone the Arc).
                    stripes[stripe_idx].push(seg.clone());
                } else {
                    stripes[stripe_idx].push(seg.slice(cur_offset..cur_offset + take));
                }
                filled += take;
                cur_offset += take;
                if cur_offset == seg.len() {
                    cur_segment += 1;
                    cur_offset = 0;
                }
            }
        }

        // Build batch write requests: each stripe → one file on one device (writev writes multiple
        // Bytes).
        let mut io_items: Vec<(IORequest, Vec<Bytes>)> = Vec::with_capacity(n_stripes);
        for (i, stripe_segs) in stripes.into_iter().enumerate() {
            let stripe_len: usize = stripe_segs.iter().map(|s| s.len()).sum();
            if self.verify_stripe_checksums {
                chunk_checksums.push(Self::checksum_segments(&stripe_segs));
            }
            let dev_id = self.router.chunk_device(key, i);
            let path = self.router.chunk_versioned_path(
                key,
                i,
                dev_id,
                meta.object_generation,
                meta.layout_version,
            );
            // Ensure the parent directory exists.
            if let Some(parent) = path.parent() {
                std::fs::create_dir_all(parent).ok();
            }
            chunk_devices.push(dev_id as u32);
            chunk_paths.push(path.to_string_lossy().to_string());
            io_items.push((
                IORequest {
                    path,
                    offset: 0,
                    length: stripe_len,
                },
                stripe_segs,
            ));
        }

        debug!(
            "L2 PUT striped(chunks) {} -> {} stripes ({} bytes total)",
            key.to_string_key(),
            n_stripes,
            total
        );

        let device_ids = chunk_devices
            .iter()
            .map(|id| *id as usize)
            .collect::<Vec<_>>();
        let write_bytes = io_items
            .iter()
            .map(|(request, _)| request.length as u64)
            .collect::<Vec<_>>();
        let results = self.observe_io_batch("write", "vectored", &device_ids, &write_bytes, || {
            self.executor.write_batch_vectored(io_items)
        });
        for (i, r) in results.into_iter().enumerate() {
            if let Err(e) = r {
                // Roll back the stripe files already written.
                for path in &chunk_paths[..i] {
                    let _ = self.executor.delete_file(std::path::Path::new(path));
                }
                return Err(e);
            }
            self.record_device_write(device_ids[i], Self::file_size(Path::new(&chunk_paths[i])));
        }

        meta.size = total as u64;
        meta.device_id = chunk_devices[0];
        meta.file_path = String::new();
        meta.striping = Some(StripingInfo {
            chunk_size: self.striping_chunk_size,
            chunk_devices,
            chunk_paths,
            total_size: total as u64,
            chunk_locations: Vec::new(),
            chunk_checksums,
        });
        let new_paths = meta
            .striping
            .as_ref()
            .map(|stripe| {
                stripe
                    .chunk_paths
                    .iter()
                    .map(PathBuf::from)
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();
        let committed = self.commit_metadata_with_rollback(key, &meta, &new_paths, if_absent)?;
        if !committed {
            return Ok(false);
        }
        self.writes_total.fetch_add(1, Ordering::Relaxed);
        self.striped_writes.fetch_add(1, Ordering::Relaxed);
        self.bytes_written
            .fetch_add(total as u64, Ordering::Relaxed);
        Ok(true)
    }

    fn read_striped(&self, key: &ObjectKey, stripe: &StripingInfo) -> Result<Vec<u8>> {
        // Backwards compat for the old API: go through read_striped_chunks and concat to Vec<u8>
        // (this concat is a necessary copy because old callers expect a single buffer; hot paths like
        // get_stream should switch to read_striped_chunks passthrough).
        let segments = self.read_striped_chunks(key, stripe)?;
        let total: usize = segments.iter().map(|s| s.len()).sum();
        let mut out = Vec::with_capacity(total);
        for s in &segments {
            out.extend_from_slice(s);
        }
        Ok(out)
    }

    /// Multi-segment read — zero-copy passthrough: parallel read_aligned_batch on 8 segments
    /// (O_DIRECT, bypassing page cache), returning Vec<Bytes>. Each Bytes wraps a 4KB-aligned
    /// AlignedBuffer via from_owner; upper-layer Bytes::slice for sub-chunks does not require
    /// alignment, and encoding to gRPC does not copy.
    ///
    /// Use: after get_stream gets this Vec<Bytes>, **each segment is streamed to the client as a
    /// DataChunk** without concatenating a 480MB block anywhere (the old read_striped concat's
    /// ~600ms page-fault write has been eliminated).
    fn read_striped_chunks(&self, _key: &ObjectKey, stripe: &StripingInfo) -> Result<Vec<Bytes>> {
        let reqs: Vec<IORequest> = stripe
            .chunk_paths
            .iter()
            .map(|p| IORequest {
                path: std::path::PathBuf::from(p),
                offset: 0,
                length: 0,
            })
            .collect();

        // O_DIRECT takes read_aligned_batch (tier_a override); buffered fallback takes the trait
        // default.
        let device_ids = stripe
            .chunk_devices
            .iter()
            .map(|device_id| *device_id as usize)
            .collect::<Vec<_>>();
        let read_bytes = stripe
            .chunk_paths
            .iter()
            .enumerate()
            .map(|(index, _)| {
                let offset = index as u64 * stripe.chunk_size;
                stripe
                    .total_size
                    .saturating_sub(offset)
                    .min(stripe.chunk_size)
            })
            .collect::<Vec<_>>();
        let results = self.observe_io_batch("read", "aligned", &device_ids, &read_bytes, || {
            self.executor.read_aligned_batch(&reqs)
        });
        let mut out: Vec<Bytes> = Vec::with_capacity(results.len());
        for (i, r) in results.into_iter().enumerate() {
            let chunk = r.map_err(|e| {
                if Self::is_not_found_error(&e) {
                    KVError::NotFound(format!("striped object missing chunk {}", i))
                } else {
                    KVError::Internal(format!("read striped chunk {}: {}", i, e))
                }
            })?;
            if let Some(device_id) = stripe.chunk_devices.get(i) {
                self.record_device_read(*device_id as usize, chunk.len() as u64);
            }
            self.verify_stripe_bytes(stripe, i, &chunk)?;
            out.push(chunk);
        }
        Ok(out)
    }

    /// Read a subset of stripes in one executor batch while preserving the requested order.
    ///
    /// Multi-endpoint RDMA uses this path to issue all stripes owned by one node concurrently.
    /// Returned indices remain global object stripe indices so callers can place each segment at
    /// the correct offset in the destination buffer.
    pub fn read_striped_chunks_at(
        &self,
        stripe: &StripingInfo,
        indices: &[usize],
    ) -> Result<Vec<(usize, Bytes)>> {
        let mut reqs = Vec::with_capacity(indices.len());
        let mut device_ids = Vec::with_capacity(indices.len());
        let mut read_bytes = Vec::with_capacity(indices.len());
        for &index in indices {
            let path = stripe
                .chunk_paths
                .get(index)
                .ok_or_else(|| KVError::Internal(format!("stripe index {index} out of range")))?;
            let device_id = stripe.chunk_devices.get(index).ok_or_else(|| {
                KVError::Internal(format!("stripe device index {index} out of range"))
            })?;
            let offset = index as u64 * stripe.chunk_size;
            reqs.push(IORequest {
                path: std::path::PathBuf::from(path),
                offset: 0,
                length: 0,
            });
            device_ids.push(*device_id as usize);
            read_bytes.push(
                stripe
                    .total_size
                    .saturating_sub(offset)
                    .min(stripe.chunk_size),
            );
        }

        let results =
            self.observe_io_batch("read", "aligned_subset", &device_ids, &read_bytes, || {
                self.executor.read_aligned_batch(&reqs)
            });
        if results.len() != indices.len() {
            return Err(KVError::Internal(format!(
                "read stripe subset returned {} results for {} requests",
                results.len(),
                indices.len()
            )));
        }

        let mut out = Vec::with_capacity(results.len());
        for ((&index, device_id), result) in indices.iter().zip(device_ids).zip(results) {
            let chunk = result.map_err(|error| {
                if Self::is_not_found_error(&error) {
                    KVError::NotFound(format!("striped object missing chunk {index}"))
                } else {
                    KVError::Internal(format!("read striped chunk {index}: {error}"))
                }
            })?;
            self.record_device_read(device_id, chunk.len() as u64);
            self.verify_stripe_bytes(stripe, index, &chunk)?;
            self.bytes_read
                .fetch_add(chunk.len() as u64, Ordering::Relaxed);
            out.push((index, chunk));
        }
        Ok(out)
    }

    /// Stream a subset of physical stripes into a compact caller-provided buffer.
    ///
    /// Each completion reports `(stripe_index, source_offset, object_offset, length, result)`.
    /// `source_offset` addresses the compact staging buffer while `object_offset` preserves the
    /// stripe's global position in the logical object. This lets multi-endpoint RDMA reads stage
    /// only the bytes owned by the current node and immediately transfer completed ranges to the
    /// correct client-buffer offset.
    pub fn read_striped_subset_into_ptr_stream(
        &self,
        stripe: &StripingInfo,
        indices: &[usize],
        ptr: *mut u8,
        capacity: usize,
    ) -> Result<crossbeam_channel::Receiver<(usize, usize, usize, usize, Result<usize>)>> {
        let chunk_size = stripe.chunk_size as usize;
        let total = stripe.total_size as usize;
        let stream_chunk_size = self.rdma_stream_chunk_size;
        let mut staging_cursor = 0usize;
        let mut reqs = Vec::new();
        let mut stream_meta = Vec::new();

        for &stripe_index in indices {
            let path = stripe.chunk_paths.get(stripe_index).ok_or_else(|| {
                KVError::Internal(format!("stripe index {stripe_index} out of range"))
            })?;
            let object_offset = stripe_index.checked_mul(chunk_size).ok_or_else(|| {
                KVError::Internal(format!("stripe offset overflow for index {stripe_index}"))
            })?;
            if object_offset >= total {
                return Err(KVError::Internal(format!(
                    "stripe index {stripe_index} starts beyond object size {total}"
                )));
            }
            let stripe_len = (total - object_offset).min(chunk_size);
            let staging_base = staging_cursor;
            staging_cursor = staging_cursor.checked_add(stripe_len).ok_or_else(|| {
                KVError::Internal("stripe subset staging size overflow".to_string())
            })?;
            if staging_cursor > capacity {
                return Err(KVError::Internal(format!(
                    "stripe subset staging capacity {capacity} < required {staging_cursor}"
                )));
            }

            for offset_in_stripe in (0..stripe_len).step_by(stream_chunk_size) {
                let stream_len = (stripe_len - offset_in_stripe).min(stream_chunk_size);
                let aligned_len =
                    (stream_len + DIRECT_IO_ALIGNMENT - 1) & !(DIRECT_IO_ALIGNMENT - 1);
                let source_offset = staging_base + offset_in_stripe;
                if source_offset + aligned_len > capacity {
                    return Err(KVError::Internal(format!(
                        "stripe {stripe_index} stream range exceeds staging capacity"
                    )));
                }
                let stream_ptr = unsafe { ptr.add(source_offset) };
                reqs.push((
                    IORequest {
                        path: std::path::PathBuf::from(path),
                        offset: offset_in_stripe as u64,
                        length: stream_len,
                    },
                    stream_ptr,
                    aligned_len,
                ));
                stream_meta.push((
                    stripe_index,
                    source_offset,
                    object_offset + offset_in_stripe,
                    stream_len,
                ));
            }
        }

        debug!(
            target: "contextstore_server::storage_io",
            event = "storage_io_plan",
            operation = "read",
            mode = "striped_subset_stream",
            staged_bytes = staging_cursor,
            stripe_count = indices.len(),
            request_count = reqs.len(),
            stream_chunk_size_bytes = stream_chunk_size,
        );

        let raw_rx = self.executor.read_aligned_into_ptr_stream(reqs);
        let (tx_out, rx_out) = crossbeam_channel::unbounded();
        let device_read_bytes = self.device_read_bytes_total.clone();
        let chunk_devices = stripe.chunk_devices.clone();
        let chunk_checksums = stripe.chunk_checksums.clone();
        let integrity_enabled = self.verify_stripe_checksums;
        let ptr_addr = ptr as usize;
        std::thread::spawn(move || {
            if integrity_enabled {
                let mut per_stripe: Vec<Vec<(usize, Result<usize>)>> =
                    (0..chunk_devices.len()).map(|_| Vec::new()).collect();
                let mut expected_counts = vec![0usize; chunk_devices.len()];
                for (stripe_index, _, _, _) in &stream_meta {
                    if let Some(count) = expected_counts.get_mut(*stripe_index) {
                        *count += 1;
                    }
                }

                while let Ok((event_index, result)) = raw_rx.recv() {
                    let Some(&(stripe_index, _, _, _)) = stream_meta.get(event_index) else {
                        continue;
                    };
                    let Some(events) = per_stripe.get_mut(stripe_index) else {
                        continue;
                    };
                    events.push((event_index, result));
                    if events.len() != expected_counts[stripe_index] {
                        continue;
                    }

                    let stripe_start = stripe_index * chunk_size;
                    let stripe_len = (total - stripe_start).min(chunk_size);
                    let staging_base = events
                        .iter()
                        .map(|(index, _)| stream_meta[*index].1)
                        .min()
                        .unwrap_or(0);
                    let mut integrity_error = events.iter().find_map(|(index, result)| {
                        let expected_len = stream_meta[*index].3;
                        match result {
                            Ok(bytes) if *bytes == expected_len => None,
                            Ok(bytes) => Some(KVError::NotFound(format!(
                                "striped object short read for stripe {stripe_index}: expected {expected_len}, got {bytes}"
                            ))),
                            Err(error) if StorageTier::is_not_found_error(error) => Some(
                                KVError::NotFound(format!(
                                    "striped object missing chunk {stripe_index}"
                                )),
                            ),
                            Err(error) => Some(KVError::Internal(format!(
                                "read striped chunk {stripe_index}: {error}"
                            ))),
                        }
                    });
                    if integrity_error.is_none() {
                        integrity_error = match chunk_checksums
                            .get(stripe_index)
                            .filter(|checksum| !checksum.is_empty())
                        {
                            Some(expected) => {
                                let data = unsafe {
                                    std::slice::from_raw_parts(
                                        (ptr_addr + staging_base) as *const u8,
                                        stripe_len,
                                    )
                                };
                                let actual = StorageTier::checksum_bytes(data);
                                if actual == *expected {
                                    None
                                } else {
                                    tracing::warn!(
                                        event = "stripe_integrity_check_failed",
                                        stripe_index,
                                        expected_checksum = %expected,
                                        actual_checksum = %actual,
                                        bytes = stripe_len,
                                        "stripe checksum mismatch"
                                    );
                                    Some(KVError::NotFound(format!(
                                        "striped object checksum mismatch for stripe {stripe_index}"
                                    )))
                                }
                            }
                            None => Some(KVError::NotFound(format!(
                                "striped object has no checksum for stripe {stripe_index}; rewrite required"
                            ))),
                        };
                    }

                    if let Some(error) = integrity_error {
                        let _ = tx_out.send((
                            stripe_index,
                            staging_base,
                            stripe_start,
                            stripe_len,
                            Err(error),
                        ));
                        events.clear();
                        continue;
                    }

                    for (index, result) in events.drain(..) {
                        let (stripe_index, source_offset, object_offset, length) =
                            stream_meta[index];
                        if let Ok(bytes) = result.as_ref() {
                            if let Some(device_id) = chunk_devices.get(stripe_index) {
                                if let Some(counter) = device_read_bytes.get(*device_id as usize) {
                                    counter.fetch_add(*bytes as u64, Ordering::Relaxed);
                                }
                            }
                        }
                        let _ = tx_out.send((
                            stripe_index,
                            source_offset,
                            object_offset,
                            length,
                            result,
                        ));
                    }
                }
                return;
            }

            while let Ok((event_index, result)) = raw_rx.recv() {
                let Some(&(stripe_index, source_offset, object_offset, length)) =
                    stream_meta.get(event_index)
                else {
                    continue;
                };
                let result = match result {
                    Err(error) if StorageTier::is_not_found_error(&error) => Err(
                        KVError::NotFound(format!("striped object missing chunk {stripe_index}")),
                    ),
                    other => other,
                };
                if let Ok(bytes) = result.as_ref() {
                    if let Some(device_id) = chunk_devices.get(stripe_index) {
                        if let Some(counter) = device_read_bytes.get(*device_id as usize) {
                            counter.fetch_add(*bytes as u64, Ordering::Relaxed);
                        }
                    }
                }
                let _ = tx_out.send((stripe_index, source_offset, object_offset, length, result));
            }
        });

        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read
            .fetch_add(staging_cursor as u64, Ordering::Relaxed);
        Ok(rx_out)
    }

    /// Read a single stripe of a striped object by index.
    pub fn read_striped_chunk_at(&self, stripe: &StripingInfo, index: usize) -> Result<Bytes> {
        self.read_striped_chunks_at(stripe, &[index])?
            .into_iter()
            .next()
            .map(|(_, chunk)| chunk)
            .ok_or_else(|| KVError::Internal("read stripe subset returned no result".into()))
    }

    /// Read an object using metadata supplied by the caller; do not re-lookup by logical key.
    ///
    /// This is the core path for descriptor reads: the server first validates the descriptor with
    /// metadata, then reads data using the physical layout pointed to by the same metadata, avoiding
    /// reading a different version by logical key between validation and read.
    pub fn get_with_meta(
        &self,
        key: &ObjectKey,
        meta: &BlockMeta,
    ) -> Result<Option<(Bytes, BlockMeta)>> {
        if self.purge_if_expired(key, meta)? {
            return Ok(None);
        }
        if let Some(stripe) = &meta.striping {
            let data = match self.read_striped(key, stripe) {
                Ok(data) => data,
                Err(KVError::NotFound(_)) => {
                    self.delete_metadata_if_current(key, meta)?;
                    return Ok(None);
                }
                Err(e) => return Err(e),
            };
            self.reads_total.fetch_add(1, Ordering::Relaxed);
            self.bytes_read
                .fetch_add(data.len() as u64, Ordering::Relaxed);
            return Ok(Some((Bytes::from(data), meta.clone())));
        }

        let path = self.meta_path_or_route(key, meta);
        if !self.executor.file_exists(&path) {
            self.delete_metadata_if_current(key, meta)?;
            return Ok(None);
        }
        let data = self.read_file_on_device(self.meta_device_or_route(key, meta), &path)?;
        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read
            .fetch_add(data.len() as u64, Ordering::Relaxed);
        self.record_device_read(self.meta_device_or_route(key, meta), data.len() as u64);
        Ok(Some((Bytes::from(data), meta.clone())))
    }

    /// Multi-segment descriptor read; does not re-lookup by logical key.
    pub fn get_chunks_with_meta(
        &self,
        key: &ObjectKey,
        meta: &BlockMeta,
    ) -> Result<Option<(Vec<Bytes>, BlockMeta)>> {
        if self.purge_if_expired(key, meta)? {
            return Ok(None);
        }
        if let Some(stripe) = &meta.striping {
            let segments = match self.read_striped_chunks(key, stripe) {
                Ok(segments) => segments,
                Err(KVError::NotFound(_)) => {
                    self.delete_metadata_if_current(key, meta)?;
                    return Ok(None);
                }
                Err(e) => return Err(e),
            };
            let total: u64 = segments.iter().map(|s| s.len() as u64).sum();
            self.reads_total.fetch_add(1, Ordering::Relaxed);
            self.bytes_read.fetch_add(total, Ordering::Relaxed);
            return Ok(Some((segments, meta.clone())));
        }

        let path = self.meta_path_or_route(key, meta);
        if !self.executor.file_exists(&path) {
            self.delete_metadata_if_current(key, meta)?;
            return Ok(None);
        }
        let data = self.read_file_on_device(self.meta_device_or_route(key, meta), &path)?;
        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read
            .fetch_add(data.len() as u64, Ordering::Relaxed);
        self.record_device_read(self.meta_device_or_route(key, meta), data.len() as u64);
        Ok(Some((vec![Bytes::from(data)], meta.clone())))
    }

    /// **RDMA GET data-plane only** — read directly into caller-pinned 4K-aligned memory (typical:
    /// slab extent), skipping the heap AlignedBuffer intermediary and per-chunk reg_mr.
    ///
    /// Differs from read_striped_chunks:
    /// - Old: read NVMe → heap AlignedBuffer × 8 → return Vec<Bytes> → caller serve_get_fallback
    ///   does 8 ibv_reg_mr calls (~33ms serial) + post_write × 8.
    /// - New: read NVMe → write slab ptr directly (pre-registered MR) → caller uses slab.lkey with a
    ///   single post_write, **saving 33ms of reg_mr overhead**.
    ///
    /// Parameters:
    /// - key: used for metadata lookup to get striping_info
    /// - ptr: start address of the SlabExtent obtained via slab.alloc(meta.size) (4K aligned)
    /// - capacity: max writable bytes at ptr (≥ size, 4K aligned; slab.alloc already rounds up).
    ///
    /// Returns: (actual bytes, BlockMeta) | None (key does not exist)
    ///
    /// # Safety (caller's responsibility)
    /// - ptr..ptr+capacity is entirely writable.
    /// - Not freed / mutated / shared with other workers before this function returns.
    /// - Actual bytes written are indicated by the return value (typically equal to meta.size).
    pub fn get_into_ptr(
        &self,
        key: &ObjectKey,
        ptr: *mut u8,
        capacity: usize,
    ) -> Result<Option<(usize, BlockMeta)>> {
        let str_key = key.to_string_key();
        let meta = match self.metadata.get_block(&str_key)? {
            Some(m) => m,
            None => return Ok(None),
        };
        if self.purge_if_expired(key, &meta)? {
            return Ok(None);
        }

        // Non-striped single file.
        let Some(stripe) = &meta.striping else {
            let path = self.meta_path_or_route(key, &meta);
            if !self.executor.file_exists(&path) {
                self.delete_metadata_if_current(key, &meta)?;
                return Ok(None);
            }
            let req = IORequest {
                path,
                offset: 0,
                length: 0,
            };
            let device_id = self.meta_device_or_route(key, &meta);
            let results =
                self.observe_io_batch("read", "aligned", &[device_id], &[meta.size], || {
                    self.executor
                        .read_aligned_into_ptr_batch(vec![(req, ptr, capacity)])
                });
            let bytes_read = results
                .into_iter()
                .next()
                .unwrap_or_else(|| Err(KVError::Internal("empty result".into())))?;
            self.reads_total.fetch_add(1, Ordering::Relaxed);
            self.bytes_read
                .fetch_add(bytes_read as u64, Ordering::Relaxed);
            self.record_device_read(self.meta_device_or_route(key, &meta), bytes_read as u64);
            return Ok(Some((bytes_read, meta)));
        };

        // striped: read segments in parallel into different offsets of ptr.
        let chunk_size = stripe.chunk_size as usize;
        let total = stripe.total_size as usize;
        if capacity < total {
            return Err(KVError::Internal(format!(
                "get_into_ptr: capacity {} < total {}",
                capacity, total
            )));
        }

        let n_stripes = stripe.chunk_paths.len();
        let mut reqs: Vec<(IORequest, *mut u8, usize)> = Vec::with_capacity(n_stripes);
        for (i, p) in stripe.chunk_paths.iter().enumerate() {
            let stripe_offset = i * chunk_size;
            let stripe_end = ((i + 1) * chunk_size).min(total);
            let stripe_len = stripe_end - stripe_offset;
            // 4K-aligned round-up length for this stripe (used for capacity checks; tier_b
            // recomputes internally).
            let aligned_stripe = (stripe_len + 4095) & !4095;
            let stripe_ptr = unsafe { ptr.add(stripe_offset) };
            // Capacity for this stripe = capacity - stripe_offset (but at least aligned_stripe).
            // Simplified: use chunk_size (matches the PUT path, each stripe is at most chunk_size).
            let stripe_cap = (capacity - stripe_offset).min((chunk_size + 4095) & !4095);
            if stripe_cap < aligned_stripe {
                return Err(KVError::Internal(format!(
                    "stripe {} cap {} < aligned {}",
                    i, stripe_cap, aligned_stripe
                )));
            }
            reqs.push((
                IORequest {
                    path: std::path::PathBuf::from(p),
                    offset: 0,
                    length: 0,
                },
                stripe_ptr,
                stripe_cap,
            ));
        }

        // Read 8 offsets of ptr in parallel (tier_b groups by device across different rings).
        let device_ids = stripe
            .chunk_devices
            .iter()
            .map(|device_id| *device_id as usize)
            .collect::<Vec<_>>();
        let read_bytes = stripe
            .chunk_paths
            .iter()
            .enumerate()
            .map(|(index, _)| {
                let offset = index as u64 * stripe.chunk_size;
                stripe
                    .total_size
                    .saturating_sub(offset)
                    .min(stripe.chunk_size)
            })
            .collect::<Vec<_>>();
        let results = self.observe_io_batch("read", "aligned", &device_ids, &read_bytes, || {
            self.executor.read_aligned_into_ptr_batch(reqs)
        });
        let mut total_read = 0usize;
        for (i, r) in results.into_iter().enumerate() {
            let n = match r {
                Ok(n) => n,
                Err(e) if Self::is_not_found_error(&e) => {
                    self.delete_metadata_if_current(key, &meta)?;
                    return Ok(None);
                }
                Err(e) => {
                    return Err(KVError::Internal(format!(
                        "read stripe {} into ptr: {}",
                        i, e
                    )));
                }
            };
            if let Some(device_id) = stripe.chunk_devices.get(i) {
                self.record_device_read(*device_id as usize, n as u64);
            }
            let stripe_offset = i * chunk_size;
            let stripe_len = ((i + 1) * chunk_size).min(total) - stripe_offset;
            if n != stripe_len {
                self.delete_metadata_if_current(key, &meta)?;
                return Ok(None);
            }
            let stripe_ptr = unsafe { ptr.add(stripe_offset) };
            if let Err(KVError::NotFound(_)) = self.verify_stripe_bytes(
                stripe,
                i,
                // The executor has completed this stripe before returning its byte count.
                unsafe { std::slice::from_raw_parts(stripe_ptr, stripe_len) },
            ) {
                self.delete_metadata_if_current(key, &meta)?;
                return Ok(None);
            }
            total_read += n;
        }
        if total_read != total {
            // Not fatal (the kernel may 0-pad to 4K), but log it.
            tracing::warn!(
                "get_into_ptr: read {} bytes != expected {} (key={})",
                total_read,
                total,
                str_key
            );
        }
        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read.fetch_add(total as u64, Ordering::Relaxed);
        Ok(Some((total, meta)))
    }

    /// **RDMA GET data-plane pipeline version** — like `get_into_ptr`, reads directly into ptr, but
    /// streams per-stripe completion events over a channel (instead of waiting for all stripes to
    /// complete).
    ///
    /// Use: as soon as the server receives a stripe completion event, it can post the corresponding
    /// RDMA WRITE, so storage read and RDMA WRITE truly overlap (vs `get_into_ptr` which is serial).
    ///
    /// Returns:
    /// - Ok(Some((meta, Receiver))): contains BlockMeta + completion event channel
    ///   - Each recv yields (stripe_idx, stripe_offset, stripe_len, Result<bytes_read>)
    ///   - stripe_idx: 0..n_stripes
    ///   - stripe_offset: byte offset within the whole value (used to compute dst_addr)
    ///   - stripe_len: bytes for this stripe (used for post_write length)
    ///   - After all stripes complete, the channel closes and recv returns Err.
    /// - Ok(None): key does not exist
    /// - Err(e): metadata error, etc.
    ///
    /// # Safety
    /// - ptr..ptr+capacity must not be freed/mutated before every recv completes.
    /// - Non-striped (single file) returns a single event (stripe_idx=0, offset=0).
    ///
    /// Non-striped takes the old path (get_into_ptr single IO) since single files have no split
    /// meaning.
    pub fn get_into_ptr_stream(
        &self,
        key: &ObjectKey,
        ptr: *mut u8,
        capacity: usize,
    ) -> Result<
        Option<(
            BlockMeta,
            crossbeam_channel::Receiver<(usize, usize, usize, Result<usize>)>,
        )>,
    > {
        let str_key = key.to_string_key();
        let meta = match self.metadata.get_block(&str_key)? {
            Some(m) => m,
            None => return Ok(None),
        };
        if self.purge_if_expired(key, &meta)? {
            return Ok(None);
        }
        self.get_into_ptr_stream_with_meta(key, &meta, ptr, capacity)
    }

    /// RDMA pipeline read path with metadata already resolved.
    ///
    /// The descriptor/RDMA path first rebuilds the physical layout from the descriptor and then
    /// calls this method to read, avoiding a re-lookup by logical key on the data plane that could
    /// hit a different version.
    pub fn get_into_ptr_stream_with_meta(
        &self,
        key: &ObjectKey,
        meta: &BlockMeta,
        ptr: *mut u8,
        capacity: usize,
    ) -> Result<
        Option<(
            BlockMeta,
            crossbeam_channel::Receiver<(usize, usize, usize, Result<usize>)>,
        )>,
    > {
        let str_key = key.to_string_key();
        let meta = meta.clone();
        if self.purge_if_expired(key, &meta)? {
            return Ok(None);
        }
        // Non-striped: fall back to the old get_into_ptr (single IO, sync read),
        // then wrap it in a single-event channel to keep a uniform interface.
        let Some(stripe) = &meta.striping else {
            let path = self.meta_path_or_route(key, &meta);
            if !self.executor.file_exists(&path) {
                self.delete_metadata_if_current(key, &meta)?;
                return Ok(None);
            }
            let total = meta.size as usize;
            let req = IORequest {
                path,
                offset: 0,
                length: 0,
            };
            debug!(
                target: "contextstore_server::storage_io",
                event = "storage_io_plan",
                operation = "read",
                mode = "single",
                key = %str_key,
                total_bytes = total,
                request_count = 1,
                capacity_bytes = capacity,
            );
            let rx = self
                .executor
                .read_aligned_into_ptr_stream(vec![(req, ptr, capacity)]);
            // Wrap in a channel to add stripe_offset info.
            let (tx, rx_out) = crossbeam_channel::unbounded();
            let device_id = self.meta_device_or_route(key, &meta);
            let device_read_bytes = self.device_read_bytes_total.clone();
            std::thread::spawn(move || {
                if let Ok((_idx, result)) = rx.recv() {
                    if let Ok(n) = result.as_ref() {
                        if let Some(counter) = device_read_bytes.get(device_id) {
                            counter.fetch_add(*n as u64, Ordering::Relaxed);
                        }
                    }
                    let _ = tx.send((0usize, 0usize, total, result));
                }
            });
            self.reads_total.fetch_add(1, Ordering::Relaxed);
            self.bytes_read.fetch_add(total as u64, Ordering::Relaxed);
            return Ok(Some((meta, rx_out)));
        };

        // striped: prepare N IORequests reading into N offsets of ptr.
        let chunk_size = stripe.chunk_size as usize;
        let total = stripe.total_size as usize;
        if capacity < total {
            return Err(KVError::Internal(format!(
                "get_into_ptr_stream: capacity {} < total {}",
                capacity, total
            )));
        }

        let n_stripes = stripe.chunk_paths.len();
        let stream_chunk_size = self.rdma_stream_chunk_size;
        let estimated_requests = n_stripes.saturating_mul(chunk_size.div_ceil(stream_chunk_size));
        let mut reqs: Vec<(IORequest, *mut u8, usize)> = Vec::with_capacity(estimated_requests);
        // Record each streamed subrange's logical value offset and length.
        let mut stream_meta: Vec<(usize, usize, usize)> = Vec::with_capacity(estimated_requests);
        for (i, p) in stripe.chunk_paths.iter().enumerate() {
            let stripe_offset = i * chunk_size;
            let stripe_end = ((i + 1) * chunk_size).min(total);
            let stripe_len = stripe_end - stripe_offset;
            for offset_in_stripe in (0..stripe_len).step_by(stream_chunk_size) {
                let stream_len = (stripe_len - offset_in_stripe).min(stream_chunk_size);
                let aligned_len =
                    (stream_len + DIRECT_IO_ALIGNMENT - 1) & !(DIRECT_IO_ALIGNMENT - 1);
                let offset_in_value = stripe_offset + offset_in_stripe;
                let stream_ptr = unsafe { ptr.add(offset_in_value) };
                let stream_cap = capacity - offset_in_value;
                if stream_cap < aligned_len {
                    return Err(KVError::Internal(format!(
                        "stripe {} stream offset {} cap {} < aligned {}",
                        i, offset_in_stripe, stream_cap, aligned_len
                    )));
                }
                reqs.push((
                    IORequest {
                        path: std::path::PathBuf::from(p),
                        offset: offset_in_stripe as u64,
                        length: stream_len,
                    },
                    stream_ptr,
                    aligned_len,
                ));
                stream_meta.push((i, offset_in_value, stream_len));
            }
        }
        let min_stream_len = stream_meta
            .iter()
            .map(|(_, _, len)| *len)
            .min()
            .unwrap_or(0);
        let max_stream_len = stream_meta
            .iter()
            .map(|(_, _, len)| *len)
            .max()
            .unwrap_or(0);
        debug!(
            target: "contextstore_server::storage_io",
            event = "storage_io_plan",
            operation = "read",
            mode = "striped",
            key = %str_key,
            total_bytes = total,
            stripe_chunk_size_bytes = chunk_size,
            stream_chunk_size_bytes = stream_chunk_size,
            stripe_count = n_stripes,
            request_count = reqs.len(),
            min_request_bytes = min_stream_len,
            max_request_bytes = max_stream_len,
        );

        // Call executor's stream API to get an (idx, Result) event stream.
        let raw_rx = self.executor.read_aligned_into_ptr_stream(reqs);

        // Add a translation layer converting (idx, Result<usize>) into (idx, offset, len,
        // Result<usize>). Use a spawn to forward without blocking.
        let (tx_out, rx_out) = crossbeam_channel::unbounded();
        let device_read_bytes = self.device_read_bytes_total.clone();
        let chunk_devices = stripe.chunk_devices.clone();
        let chunk_checksums = stripe.chunk_checksums.clone();
        let integrity_enabled = self.verify_stripe_checksums;
        let metadata = self.metadata.clone();
        let cleanup_key = str_key.clone();
        let cleanup_meta = meta.clone();
        let ptr_addr = ptr as usize;
        std::thread::spawn(move || {
            if integrity_enabled {
                let mut per_stripe: Vec<Vec<(usize, Result<usize>)>> =
                    (0..n_stripes).map(|_| Vec::new()).collect();
                let mut expected_counts = vec![0usize; n_stripes];
                let mut metadata_deleted = false;
                for (stripe_idx, _, _) in &stream_meta {
                    expected_counts[*stripe_idx] += 1;
                }

                while let Ok((idx, result)) = raw_rx.recv() {
                    if idx >= stream_meta.len() {
                        continue;
                    }
                    let stripe_idx = stream_meta[idx].0;
                    per_stripe[stripe_idx].push((idx, result));
                    if per_stripe[stripe_idx].len() != expected_counts[stripe_idx] {
                        continue;
                    }

                    let stripe_offset = stripe_idx * chunk_size;
                    let stripe_len = ((stripe_idx + 1) * chunk_size).min(total) - stripe_offset;
                    let mut integrity_error = per_stripe[stripe_idx].iter().find_map(
                        |(event_idx, result)| match result {
                            Ok(n) if *n == stream_meta[*event_idx].2 => None,
                            Ok(_) => Some(KVError::NotFound(format!(
                                "striped object short read for stripe {}",
                                stripe_idx
                            ))),
                            Err(error) if StorageTier::is_not_found_error(error) => {
                                Some(KVError::NotFound(format!(
                                    "striped object missing chunk {}",
                                    stripe_idx
                                )))
                            }
                            Err(error) => Some(KVError::Internal(format!(
                                "read striped chunk {}: {}",
                                stripe_idx, error
                            ))),
                        },
                    );
                    if integrity_error.is_none() {
                        let expected = chunk_checksums
                            .get(stripe_idx)
                            .filter(|checksum| !checksum.is_empty());
                        integrity_error = match expected {
                            Some(expected) => {
                                let data = unsafe {
                                    std::slice::from_raw_parts(
                                        (ptr_addr + stripe_offset) as *const u8,
                                        stripe_len,
                                    )
                                };
                                let actual = StorageTier::checksum_bytes(data);
                                if actual == *expected {
                                    None
                                } else {
                                    tracing::warn!(
                                        event = "stripe_integrity_check_failed",
                                        stripe_index = stripe_idx,
                                        expected_checksum = %expected,
                                        actual_checksum = %actual,
                                        bytes = stripe_len,
                                        "stripe checksum mismatch"
                                    );
                                    Some(KVError::NotFound(format!(
                                        "striped object checksum mismatch for stripe {}",
                                        stripe_idx
                                    )))
                                }
                            }
                            None => Some(KVError::NotFound(format!(
                                "striped object has no checksum for stripe {}; rewrite required",
                                stripe_idx
                            ))),
                        };
                    }

                    if let Some(error) = integrity_error {
                        if !metadata_deleted {
                            let _ = metadata.delete_block_if_matches(&cleanup_key, &cleanup_meta);
                            metadata_deleted = true;
                        }
                        let (event_idx, off, len) = stream_meta[per_stripe[stripe_idx][0].0];
                        let _ = tx_out.send((event_idx, off, len, Err(error)));
                        continue;
                    }

                    for (event_idx, result) in per_stripe[stripe_idx].drain(..) {
                        if let Ok(n) = result.as_ref() {
                            if let Some(device_id) = chunk_devices.get(stripe_idx) {
                                if let Some(counter) = device_read_bytes.get(*device_id as usize) {
                                    counter.fetch_add(*n as u64, Ordering::Relaxed);
                                }
                            }
                        }
                        let (_, off, len) = stream_meta[event_idx];
                        let _ = tx_out.send((event_idx, off, len, result));
                    }
                }
                return;
            }

            while let Ok((idx, result)) = raw_rx.recv() {
                if idx < stream_meta.len() {
                    let result = match result {
                        Err(e) if StorageTier::is_not_found_error(&e) => {
                            let _ = metadata.delete_block_if_matches(&cleanup_key, &cleanup_meta);
                            Err(KVError::NotFound(format!(
                                "striped object missing chunk {}",
                                idx
                            )))
                        }
                        other => other,
                    };
                    if let Ok(n) = result.as_ref() {
                        let stripe_idx = stream_meta[idx].0;
                        if let Some(device_id) = chunk_devices.get(stripe_idx) {
                            if let Some(counter) = device_read_bytes.get(*device_id as usize) {
                                counter.fetch_add(*n as u64, Ordering::Relaxed);
                            }
                        }
                    }
                    let (_, off, len) = stream_meta[idx];
                    let _ = tx_out.send((idx, off, len, result));
                }
            }
        });

        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read.fetch_add(total as u64, Ordering::Relaxed);
        Ok(Some((meta, rx_out)))
    }

    /// Multi-segment GET — zero-copy passthrough: striped keys return Vec<Bytes> directly;
    /// non-striped single files return a single-element Vec. The caller (get_stream) streams the
    /// Bytes segments to the client without concatenating.
    pub fn get_chunks(&self, key: &ObjectKey) -> Result<Option<(Vec<Bytes>, BlockMeta)>> {
        let str_key = key.to_string_key();
        let meta = match self.metadata.get_block(&str_key)? {
            Some(m) => m,
            None => return Ok(None),
        };
        if self.purge_if_expired(key, &meta)? {
            return Ok(None);
        }

        if let Some(stripe) = &meta.striping {
            let segments = match self.read_striped_chunks(key, stripe) {
                Ok(segments) => segments,
                Err(KVError::NotFound(_)) => {
                    self.delete_metadata_if_current(key, &meta)?;
                    return Ok(None);
                }
                Err(e) => return Err(e),
            };
            let total: u64 = segments.iter().map(|s| s.len() as u64).sum();
            self.reads_total.fetch_add(1, Ordering::Relaxed);
            self.bytes_read.fetch_add(total, Ordering::Relaxed);
            return Ok(Some((segments, meta)));
        }

        let path = self.meta_path_or_route(key, &meta);
        if !self.executor.file_exists(&path) {
            self.delete_metadata_if_current(key, &meta)?;
            return Ok(None);
        }
        let data = self.read_file_on_device(self.meta_device_or_route(key, &meta), &path)?;
        self.reads_total.fetch_add(1, Ordering::Relaxed);
        self.bytes_read
            .fetch_add(data.len() as u64, Ordering::Relaxed);
        self.record_device_read(self.meta_device_or_route(key, &meta), data.len() as u64);
        Ok(Some((vec![Bytes::from(data)], meta)))
    }

    // ===== Batch (parallel) =====

    /// Batch read — grouped by device and executed in parallel.
    pub fn get_batch(&self, keys: &[ObjectKey]) -> Vec<Result<Option<(Bytes, BlockMeta)>>> {
        // 1. Collect each key's metadata and path and build IORequest.
        //    striped keys take a separate path (inline read_striped, not going through batch submit).
        let mut results: Vec<Option<Result<Option<(Bytes, BlockMeta)>>>> =
            (0..keys.len()).map(|_| None).collect();
        let mut io_reqs: Vec<(usize, IORequest, BlockMeta, usize)> = Vec::new();

        for (idx, key) in keys.iter().enumerate() {
            let str_key = key.to_string_key();
            match self.metadata.get_block(&str_key) {
                Ok(Some(meta)) => {
                    match self.purge_if_expired(key, &meta) {
                        Ok(true) => {
                            results[idx] = Some(Ok(None));
                            continue;
                        }
                        Ok(false) => {}
                        Err(e) => {
                            results[idx] = Some(Err(e));
                            continue;
                        }
                    }
                    if meta.striping.is_some() {
                        // striped: handled separately (internally already a parallel read_batch).
                        let stripe = meta.striping.as_ref().unwrap().clone();
                        match self.read_striped(key, &stripe) {
                            Ok(data) => {
                                self.reads_total.fetch_add(1, Ordering::Relaxed);
                                self.bytes_read
                                    .fetch_add(data.len() as u64, Ordering::Relaxed);
                                results[idx] = Some(Ok(Some((Bytes::from(data), meta))));
                            }
                            Err(KVError::NotFound(_)) => {
                                if let Err(e) = self.delete_metadata_if_current(key, &meta) {
                                    results[idx] = Some(Err(e));
                                } else {
                                    results[idx] = Some(Ok(None));
                                }
                            }
                            Err(e) => results[idx] = Some(Err(e)),
                        }
                        continue;
                    }
                    let path = self.meta_path_or_route(key, &meta);
                    if !self.executor.file_exists(&path) {
                        if let Err(e) = self.delete_metadata_if_current(key, &meta) {
                            results[idx] = Some(Err(e));
                        } else {
                            results[idx] = Some(Ok(None));
                        }
                        continue;
                    }
                    let device_id = self.meta_device_or_route(key, &meta);
                    io_reqs.push((
                        idx,
                        IORequest {
                            path,
                            offset: 0,
                            length: 0,
                        },
                        meta,
                        device_id,
                    ));
                }
                Ok(None) => {
                    results[idx] = Some(Ok(None));
                }
                Err(e) => {
                    results[idx] = Some(Err(e));
                }
            }
        }

        // 2. BatchOptimizer: group by (device → sorted paths) to reduce random I/O.
        //    Router already implicitly routes key→device; here we sort by path to exploit sequential
        //    reads.
        io_reqs.sort_by(|a, b| a.1.path.cmp(&b.1.path));

        // 3. Submit I/O in batch (executor is internally parallel).
        let reqs: Vec<IORequest> = io_reqs
            .iter()
            .map(|(_, r, _, _)| IORequest {
                path: r.path.clone(),
                offset: r.offset,
                length: r.length,
            })
            .collect();
        let device_ids = io_reqs
            .iter()
            .map(|(_, _, _, device_id)| *device_id)
            .collect::<Vec<_>>();
        let read_bytes = io_reqs
            .iter()
            .map(|(_, _, meta, _)| meta.size)
            .collect::<Vec<_>>();
        let read_results = self.observe_io_batch("read", "batch", &device_ids, &read_bytes, || {
            self.executor.read_batch(&reqs)
        });

        // 4. Fill results back in.
        for ((idx, _, meta, device_id), data_res) in
            io_reqs.into_iter().zip(read_results.into_iter())
        {
            match data_res {
                Ok(data) => {
                    self.reads_total.fetch_add(1, Ordering::Relaxed);
                    self.bytes_read
                        .fetch_add(data.len() as u64, Ordering::Relaxed);
                    self.record_device_read(device_id, data.len() as u64);
                    // Vec<u8> → Bytes zero-copy handoff.
                    results[idx] = Some(Ok(Some((Bytes::from(data), meta))));
                }
                Err(e) => results[idx] = Some(Err(e)),
            }
        }

        results
            .into_iter()
            .map(|r| r.unwrap_or_else(|| Err(KVError::Internal("missing slot".to_string()))))
            .collect()
    }

    /// Batch write.
    pub fn put_batch(&self, items: Vec<(ObjectKey, Bytes, BlockMeta)>) -> Vec<Result<()>> {
        items
            .into_iter()
            .map(|(key, data, meta)| self.put(&key, data, meta))
            .collect()
    }
}

fn directory_size_bytes(path: &Path) -> u64 {
    let Ok(entries) = std::fs::read_dir(path) else {
        return 0;
    };
    entries
        .flatten()
        .map(|entry| {
            let path = entry.path();
            match entry.file_type() {
                Ok(file_type) if file_type.is_dir() => directory_size_bytes(&path),
                Ok(file_type) if file_type.is_file() => {
                    entry.metadata().map(|metadata| metadata.len()).unwrap_or(0)
                }
                _ => 0,
            }
        })
        .sum()
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    fn test_config(dir: &std::path::Path) -> Config {
        test_config_with_devices(dir, 2)
    }

    fn test_config_with_devices(dir: &std::path::Path, n_devices: usize) -> Config {
        let mut cfg = Config::default();
        cfg.storage.devices = (0..n_devices)
            .map(|i| dir.join(format!("nvme{}", i)))
            .collect();
        cfg.metadata.redis_url = format!("memory://storage-tier-{}", dir.display());
        cfg
    }

    fn mk_meta() -> BlockMeta {
        BlockMeta {
            device_id: 0,
            file_path: String::new(),
            size: 0,
            object_handle: String::new(),
            object_generation: 1,
            content_etag: String::new(),
            layout_version: 1,
            created_at: 0,
            last_accessed_at: 0,
            ttl_seconds: 0,
            num_tokens: 128,
            num_layers: 1,
            dtype: "bfloat16".to_string(),
            compressed: false,
            striping: None,
        }
    }

    fn expired_meta() -> BlockMeta {
        let mut meta = mk_meta();
        meta.created_at = chrono::Utc::now().timestamp() - 10;
        meta.ttl_seconds = 1;
        meta
    }

    fn mark_expired(st: &StorageTier, key: &ObjectKey) -> BlockMeta {
        let mut meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        meta.created_at = chrono::Utc::now().timestamp() - 10;
        meta.ttl_seconds = 1;
        st.metadata.put_block(&key.to_string_key(), &meta).unwrap();
        meta
    }

    fn flatten_segments(segments: &[Bytes]) -> Vec<u8> {
        segments
            .iter()
            .flat_map(|segment| segment.iter().copied())
            .collect()
    }

    fn regular_files(root: &std::path::Path) -> Vec<std::path::PathBuf> {
        let mut files = Vec::new();
        if !root.exists() {
            return files;
        }
        let entries = std::fs::read_dir(root).unwrap();
        for entry in entries {
            let path = entry.unwrap().path();
            if path.is_dir() {
                files.extend(regular_files(&path));
            } else if path.is_file() {
                files.push(path);
            }
        }
        files.sort();
        files
    }

    #[cfg(not(feature = "metrics"))]
    #[test]
    fn disabled_metrics_skip_startup_capacity_scan() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let data_dir = cfg.storage.devices[0]
            .join(&cfg.storage.data_subdir)
            .join("data");
        std::fs::create_dir_all(&data_dir).unwrap();
        std::fs::write(data_dir.join("existing.bin"), b"existing").unwrap();

        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();

        assert_eq!(st.device_used_bytes(0), 0);
    }

    #[test]
    fn put_get_delete_roundtrip() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "abcdef/layer_0".into(),
        };
        st.put(&key, Bytes::from_static(b"hello"), mk_meta())
            .unwrap();
        let (data, meta) = st.get(&key).unwrap().unwrap();
        assert_eq!(data.as_ref(), b"hello");
        assert_eq!(meta.object_generation, 1);
        assert!(!meta.content_etag.is_empty());
        assert_eq!(meta.layout_version, 1);
        let first_etag = meta.content_etag.clone();

        st.put(&key, Bytes::from_static(b"hello-again"), mk_meta())
            .unwrap();
        let (data, meta) = st.get(&key).unwrap().unwrap();
        assert_eq!(data.as_ref(), b"hello-again");
        assert_eq!(meta.object_generation, 2);
        assert_ne!(meta.content_etag, first_etag);
        assert_eq!(meta.layout_version, 1);

        assert!(st.exists(&key).unwrap());
        assert!(st.delete(&key).unwrap());
        assert!(!st.exists(&key).unwrap());
    }

    #[test]
    fn put_if_absent_does_not_overwrite_existing_object() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "immutable/object".into(),
        };

        assert!(st
            .put_if_absent(&key, Bytes::from_static(b"first"), mk_meta())
            .unwrap());
        let first_meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();

        assert!(!st
            .put_if_absent(&key, Bytes::from_static(b"second"), mk_meta())
            .unwrap());
        let (data, meta) = st.get(&key).unwrap().unwrap();

        assert_eq!(data.as_ref(), b"first");
        assert_eq!(meta.object_generation, first_meta.object_generation);
        assert_eq!(meta.content_etag, first_meta.content_etag);
        assert_eq!(meta.file_path, first_meta.file_path);
    }

    #[test]
    fn stripe_integrity_is_opt_in_and_corruption_becomes_cache_miss() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 8;
        cfg.storage.striping_chunk_size = 4;
        cfg.storage.verify_stripe_checksums = true;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "integrity/striped".into(),
        };

        st.put(&key, Bytes::from_static(b"abcdefghijkl"), mk_meta())
            .unwrap();
        let meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let stripe = meta.striping.as_ref().unwrap();
        assert_eq!(stripe.chunk_checksums.len(), 3);
        assert!(stripe
            .chunk_checksums
            .iter()
            .all(|checksum| checksum.len() == 16));

        std::fs::write(&stripe.chunk_paths[1], b"XXXX").unwrap();
        assert!(st.get(&key).unwrap().is_none());
        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
    }

    #[test]
    fn stripe_integrity_disabled_keeps_legacy_read_behavior() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 8;
        cfg.storage.striping_chunk_size = 4;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "integrity/disabled".into(),
        };

        st.put(&key, Bytes::from_static(b"abcdefghijkl"), mk_meta())
            .unwrap();
        let meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let stripe = meta.striping.as_ref().unwrap();
        assert!(stripe.chunk_checksums.is_empty());

        std::fs::write(&stripe.chunk_paths[1], b"XXXX").unwrap();
        let (data, _) = st.get(&key).unwrap().unwrap();
        assert_eq!(data.as_ref(), b"abcdXXXXijkl");
    }

    #[test]
    fn stripe_subset_read_preserves_indices_and_checks_integrity() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 8;
        cfg.storage.striping_chunk_size = 4;
        cfg.storage.verify_stripe_checksums = true;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "integrity/subset".into(),
        };

        st.put(&key, Bytes::from_static(b"abcdefghijkl"), mk_meta())
            .unwrap();
        let meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let stripe = meta.striping.as_ref().unwrap();

        let chunks = st.read_striped_chunks_at(stripe, &[2, 0]).unwrap();
        assert_eq!(chunks[0].0, 2);
        assert_eq!(chunks[0].1.as_ref(), b"ijkl");
        assert_eq!(chunks[1].0, 0);
        assert_eq!(chunks[1].1.as_ref(), b"abcd");

        std::fs::write(&stripe.chunk_paths[2], b"XXXX").unwrap();
        assert!(matches!(
            st.read_striped_chunks_at(stripe, &[2]),
            Err(KVError::NotFound(_))
        ));
    }

    #[test]
    fn placement_chunk_integrity_rejects_corruption() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.verify_stripe_checksums = true;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "integrity/placement".into(),
        };

        let (_device_id, path, checksum) = st
            .put_placement_chunk(&key, 0, 0, 1, 1, Bytes::from_static(b"placement"))
            .unwrap();
        std::fs::write(&path, b"corrupted").unwrap();
        let err = st
            .read_placement_chunk(&path, 9, Some(&checksum))
            .unwrap_err();
        assert!(matches!(err, KVError::NotFound(_)));
    }

    #[test]
    fn placement_chunk_integrity_skips_non_striped_objects() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.verify_stripe_checksums = true;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "integrity/non-striped-placement".into(),
        };

        let (_device_id, path, _checksum) = st
            .put_placement_chunk(&key, 0, 0, 1, 1, Bytes::from_static(b"placement"))
            .unwrap();
        let data = st.read_placement_chunk(&path, 9, None).unwrap().unwrap();
        assert_eq!(data.as_ref(), b"placement");
    }

    #[test]
    fn expired_single_object_is_retired_on_get() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "ttl/single".into(),
        };

        st.put(&key, Bytes::from_static(b"expired"), mk_meta())
            .unwrap();
        let path = mark_expired(&st, &key).file_path;
        assert!(std::path::Path::new(&path).exists());

        assert!(st.get(&key).unwrap().is_none());
        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
        assert!(std::path::Path::new(&path).exists());
        assert_eq!(
            st.metadata
                .take_due_gc_tasks(
                    chrono::Utc::now().timestamp() + cfg.gc.grace_seconds as i64,
                    1,
                    1
                )
                .unwrap()
                .len(),
            1
        );
    }

    #[test]
    fn expired_striped_object_is_retired_on_get() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 8;
        cfg.storage.striping_chunk_size = 4;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "ttl/striped".into(),
        };

        st.put(&key, Bytes::from_static(b"abcdefghijkl"), mk_meta())
            .unwrap();
        let paths = mark_expired(&st, &key).striping.unwrap().chunk_paths;
        assert!(paths.iter().all(|path| std::path::Path::new(path).exists()));

        assert!(st.get(&key).unwrap().is_none());
        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
        assert!(paths.iter().all(|path| std::path::Path::new(path).exists()));
        assert_eq!(
            st.metadata
                .take_due_gc_tasks(
                    chrono::Utc::now().timestamp() + cfg.gc.grace_seconds as i64,
                    1,
                    1
                )
                .unwrap()
                .len(),
            1
        );
    }

    #[test]
    fn expired_object_retires_metadata_without_synchronous_chunk_cleanup() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "ttl/partial-cleanup".into(),
        };
        let valid_path = cfg.storage.devices[1].join("expired-chunk.bin");
        std::fs::write(&valid_path, b"chunk").unwrap();
        let mut meta = expired_meta();
        meta.striping = Some(StripingInfo {
            chunk_size: 4,
            chunk_devices: Vec::new(),
            chunk_paths: vec![
                "/unmanaged/missing-chunk.bin".to_string(),
                valid_path.display().to_string(),
            ],
            total_size: 5,
            chunk_locations: Vec::new(),
            chunk_checksums: Vec::new(),
        });
        st.metadata.put_block(&key.to_string_key(), &meta).unwrap();

        assert!(!st.exists(&key).unwrap());
        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
        assert!(valid_path.exists());
    }

    #[test]
    fn put_if_absent_can_replace_expired_object() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "ttl/if-absent".into(),
        };

        assert!(st
            .put_if_absent(&key, Bytes::from_static(b"old"), mk_meta())
            .unwrap());
        mark_expired(&st, &key);
        assert!(st
            .put_if_absent(&key, Bytes::from_static(b"new"), mk_meta())
            .unwrap());
        let (data, _) = st.get(&key).unwrap().unwrap();

        assert_eq!(data.as_ref(), b"new");
    }

    #[test]
    fn metadata_put_failure_rolls_back_single_file() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "failure/single".into(),
        };

        st.metadata.fail_next_put_for_test();
        assert!(st
            .put(&key, Bytes::from_static(b"uncommitted"), mk_meta())
            .is_err());

        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
        assert!(regular_files(tmp.path()).is_empty());
    }

    #[test]
    fn striped_delete_continues_after_unroutable_chunk() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "cleanup/striped".into(),
        };
        let valid_path = cfg.storage.devices[1].join("remaining-chunk.bin");
        std::fs::write(&valid_path, b"chunk").unwrap();
        let mut meta = mk_meta();
        meta.striping = Some(StripingInfo {
            chunk_size: 4,
            chunk_devices: Vec::new(),
            chunk_paths: vec![
                "/unmanaged/missing-chunk.bin".to_string(),
                valid_path.display().to_string(),
            ],
            total_size: 5,
            chunk_locations: Vec::new(),
            chunk_checksums: Vec::new(),
        });

        assert!(st.delete_files_for_meta(&key, &meta).is_err());
        assert!(!valid_path.exists());
    }

    #[test]
    fn metadata_put_failure_rolls_back_striped_chunks() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 8;
        cfg.storage.striping_chunk_size = 4;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "failure/striped".into(),
        };

        st.metadata.fail_next_put_for_test();
        assert!(st
            .put(&key, Bytes::from_static(b"abcdefghijkl"), mk_meta())
            .is_err());

        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
        assert!(regular_files(tmp.path()).is_empty());
    }

    #[test]
    fn missing_single_file_clears_current_metadata() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "missing/single".into(),
        };

        st.put(&key, Bytes::from_static(b"value"), mk_meta())
            .unwrap();
        let meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        std::fs::remove_file(&meta.file_path).unwrap();

        assert!(st.get(&key).unwrap().is_none());
        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
        assert!(!st.exists(&key).unwrap());
    }

    #[test]
    fn missing_striped_chunk_clears_current_metadata() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 8;
        cfg.storage.striping_chunk_size = 4;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "missing/striped".into(),
        };

        st.put(&key, Bytes::from_static(b"abcdefghijkl"), mk_meta())
            .unwrap();
        let meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let missing_path = meta.striping.as_ref().unwrap().chunk_paths[0].clone();
        std::fs::remove_file(missing_path).unwrap();

        assert!(st.get(&key).unwrap().is_none());
        assert!(st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .is_none());
        assert!(!st.exists(&key).unwrap());
    }

    #[test]
    fn put_chunks_if_absent_does_not_overwrite_striped_object() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 8;
        cfg.storage.striping_chunk_size = 4;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "immutable/striped".into(),
        };

        assert!(st
            .put_chunks_if_absent(
                &key,
                vec![Bytes::from_static(b"abcd"), Bytes::from_static(b"efghij")],
                mk_meta(),
            )
            .unwrap());
        let first_meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();

        assert!(!st
            .put_chunks_if_absent(
                &key,
                vec![Bytes::from_static(b"ZZZZ"), Bytes::from_static(b"YYYYYY")],
                mk_meta(),
            )
            .unwrap());
        let (segments, meta) = st.get_chunks(&key).unwrap().unwrap();

        assert_eq!(flatten_segments(&segments), b"abcdefghij");
        assert_eq!(meta.object_generation, first_meta.object_generation);
        assert_eq!(meta.content_etag, first_meta.content_etag);
        assert_eq!(
            meta.striping.unwrap().chunk_paths,
            first_meta.striping.unwrap().chunk_paths
        );
    }

    #[test]
    fn non_striped_get_uses_metadata_path_after_device_count_changes() {
        let tmp = TempDir::new().unwrap();
        let old_cfg = test_config_with_devices(tmp.path(), 2);
        let new_cfg = test_config_with_devices(tmp.path(), 3);
        let old_router = ShardRouter::new(&old_cfg).unwrap();
        let new_router = ShardRouter::new(&new_cfg).unwrap();
        let key = (0..1024)
            .map(|i| ObjectKey {
                namespace: "test".into(),
                object_key: format!("remap/object_{}", i),
            })
            .find(|k| old_router.route(k) != new_router.route(k))
            .expect("should find key remapped by device-count change");

        let old_path = {
            let router = Arc::new(ShardRouter::new(&old_cfg).unwrap());
            let st = StorageTier::new(&old_cfg, router).unwrap();
            st.put(&key, Bytes::from_static(b"stable-path"), mk_meta())
                .unwrap();
            st.metadata
                .get_block(&key.to_string_key())
                .unwrap()
                .unwrap()
                .file_path
        };

        let router = Arc::new(ShardRouter::new(&new_cfg).unwrap());
        let st = StorageTier::new(&new_cfg, router).unwrap();
        assert_ne!(
            std::path::PathBuf::from(&old_path),
            st.router.key_to_path(&key),
            "test key must route to a different path after expansion"
        );

        let (data, meta) = st.get(&key).unwrap().unwrap();
        assert_eq!(data.as_ref(), b"stable-path");
        assert_eq!(meta.file_path, old_path);
    }

    #[test]
    fn overwrite_writes_new_physical_path_without_mutating_old_file() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "overwrite/object".into(),
        };

        st.put(&key, Bytes::from_static(b"old-value"), mk_meta())
            .unwrap();
        let old_meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let old_path = std::path::PathBuf::from(&old_meta.file_path);
        assert!(old_path.exists());

        st.put(&key, Bytes::from_static(b"new-value"), mk_meta())
            .unwrap();
        let new_meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();

        assert_eq!(new_meta.object_generation, old_meta.object_generation + 1);
        assert_ne!(new_meta.object_handle, old_meta.object_handle);
        assert_ne!(new_meta.file_path, old_meta.file_path);
        assert_eq!(std::fs::read(&old_path).unwrap(), b"old-value");

        let (old_data, old_read_meta) = st.get_with_meta(&key, &old_meta).unwrap().unwrap();
        assert_eq!(old_data.as_ref(), b"old-value");
        assert_eq!(old_read_meta.object_generation, old_meta.object_generation);

        let (new_data, _) = st.get(&key).unwrap().unwrap();
        assert_eq!(new_data.as_ref(), b"new-value");
    }

    #[test]
    fn striped_overwrite_uses_new_chunk_paths() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        cfg.storage.striping_threshold = 16;
        cfg.storage.striping_chunk_size = 8;
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "overwrite/striped".into(),
        };

        st.put(&key, Bytes::from_static(b"abcdefghijklmnopq"), mk_meta())
            .unwrap();
        let old_meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let old_paths = old_meta.striping.as_ref().unwrap().chunk_paths.clone();

        st.put(&key, Bytes::from_static(b"ABCDEFGHIJKLMNOPQ"), mk_meta())
            .unwrap();
        let new_meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let new_paths = new_meta.striping.as_ref().unwrap().chunk_paths.clone();

        assert_eq!(new_meta.object_generation, old_meta.object_generation + 1);
        assert_ne!(new_paths, old_paths);
        assert!(old_paths.iter().all(|p| std::path::Path::new(p).exists()));

        let (old_segments, _) = st.get_chunks_with_meta(&key, &old_meta).unwrap().unwrap();
        let old_joined = old_segments
            .iter()
            .flat_map(|b| b.iter().copied())
            .collect::<Vec<_>>();
        assert_eq!(old_joined.as_slice(), b"abcdefghijklmnopq");
    }

    #[test]
    fn batch_distributes_to_multiple_devices() {
        let tmp = TempDir::new().unwrap();
        let cfg = test_config(tmp.path());
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let items: Vec<_> = (0..8)
            .map(|i| {
                (
                    ObjectKey {
                        namespace: "test".into(),
                        object_key: format!("abcdef/layer_{}", i),
                    },
                    Bytes::from(format!("data-{}", i).into_bytes()),
                    mk_meta(),
                )
            })
            .collect();
        let keys: Vec<_> = items.iter().map(|(k, _, _)| k.clone()).collect();
        let results = st.put_batch(items);
        for r in &results {
            r.as_ref().unwrap();
        }
        let got = st.get_batch(&keys);
        for (i, r) in got.into_iter().enumerate() {
            let (d, _) = r.unwrap().unwrap();
            assert_eq!(d.as_ref(), format!("data-{}", i).as_bytes());
        }
    }

    #[test]
    fn large_value_is_striped() {
        let tmp = TempDir::new().unwrap();
        let mut cfg = test_config(tmp.path());
        // Small threshold for easier testing.
        cfg.storage.striping_threshold = 1024; // 1KB
        cfg.storage.striping_chunk_size = 512; // 512B per chunk
        let router = Arc::new(ShardRouter::new(&cfg).unwrap());
        let st = StorageTier::new(&cfg, router).unwrap();
        let key = ObjectKey {
            namespace: "test".into(),
            object_key: "ab/huge".into(),
        };
        // 2 KB data → should be split into 4 chunks.
        let data: Vec<u8> = (0..2048u32).map(|i| (i & 0xff) as u8).collect();
        st.put(&key, Bytes::from(data.clone()), mk_meta()).unwrap();

        // Metadata should contain striping info.
        let meta = st
            .metadata
            .get_block(&key.to_string_key())
            .unwrap()
            .unwrap();
        let stripe = meta.striping.as_ref().expect("should be striped");
        assert_eq!(stripe.chunk_paths.len(), 4);
        assert_eq!(stripe.total_size, 2048);

        // Read back the full data and verify.
        let (got, _) = st.get(&key).unwrap().unwrap();
        assert_eq!(got.as_ref(), data.as_slice());

        // Delete retires the metadata immediately and preserves the chunk layout
        // until the background GC worker reaches its grace deadline.
        st.delete(&key).unwrap();
        for p in &stripe.chunk_paths {
            assert!(
                std::path::Path::new(p).exists(),
                "chunk {} should remain until GC",
                p
            );
        }
        assert_eq!(
            st.metadata
                .take_due_gc_tasks(
                    chrono::Utc::now().timestamp() + cfg.gc.grace_seconds as i64,
                    1,
                    1
                )
                .unwrap()
                .len(),
            1
        );
    }
}
