//! Reliable Connection QP — one-to-one connection with a client; use ibv_post_send WRITE after handshake

use crate::rdma::context::{MemRegion, RdmaContext};
use crate::rdma::slab::SlabExtent;
use anyhow::{anyhow, Result};
use prost::bytes::Bytes;
use rdma_sys::*;
use std::ptr::{self, NonNull};
use std::sync::{Arc, Mutex};

/// An RC QP (Reliable Connection Queue Pair).
///
/// Creation flow:
/// 1. `RcQp::new(ctx)` — create QP in RESET state
/// 2. `qp.to_init(...)` — transition to INIT
/// 3. `qp.to_rtr(remote)` — after receiving remote QP info, transition to Ready-To-Receive
/// 4. `qp.to_rts(...)` — transition to Ready-To-Send
/// 5. `qp.post_write(...)` — actual operation
pub struct RcQp {
    qp: NonNull<ibv_qp>,
    // A timed-out WRITE may still read its local MR. These buffers are
    // released only after Drop destroys the QP.
    retired_writes: Mutex<Vec<(MemRegion, Bytes)>>,
    retired_extents: Mutex<Vec<SlabExtent>>,
    retired_pins: Mutex<Vec<Arc<SlabExtent>>>,
    /// Local QP info, sent to remote over the control plane
    pub local: QpInfo,
}

unsafe impl Send for RcQp {}
unsafe impl Sync for RcQp {}

/// QP metadata, exchanged over the TCP control plane
#[derive(Clone, Copy)]
pub struct QpInfo {
    pub qpn: u32,
    pub psn: u32,
    pub gid: ibv_gid,
}

impl std::fmt::Debug for QpInfo {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        unsafe {
            f.debug_struct("QpInfo")
                .field("qpn", &self.qpn)
                .field("psn", &format!("0x{:x}", self.psn))
                .field("gid", &format!("{:02x?}", &self.gid.raw[..]))
                .finish()
        }
    }
}

impl QpInfo {
    /// Serialize to 24 bytes: 4(qpn) + 4(psn) + 16(gid)
    pub fn to_bytes(&self) -> [u8; 24] {
        let mut buf = [0u8; 24];
        buf[0..4].copy_from_slice(&self.qpn.to_le_bytes());
        buf[4..8].copy_from_slice(&self.psn.to_le_bytes());
        unsafe {
            buf[8..24].copy_from_slice(&self.gid.raw[..]);
        }
        buf
    }

    pub fn from_bytes(buf: &[u8; 24]) -> Self {
        let qpn = u32::from_le_bytes(buf[0..4].try_into().unwrap());
        let psn = u32::from_le_bytes(buf[4..8].try_into().unwrap());
        let mut gid: ibv_gid = unsafe { std::mem::zeroed() };
        unsafe {
            gid.raw[..].copy_from_slice(&buf[8..24]);
        }
        Self { qpn, psn, gid }
    }
}

impl RcQp {
    /// Maximum send work requests configured for each RDMA RC queue pair.
    pub const MAX_SEND_WR: usize = 128;

    /// Create an RC QP in RESET state. Follow with to_init/to_rtr/to_rts.
    ///
    /// `cq`: dedicated CQ (per-client) to avoid races when multiple client threads poll the same CQ concurrently.
    pub fn new(ctx: &RdmaContext, cq: NonNull<ibv_cq>) -> Result<Self> {
        unsafe {
            let mut attr = ibv_qp_init_attr {
                qp_context: ptr::null_mut(),
                send_cq: cq.as_ptr(),
                recv_cq: cq.as_ptr(),
                srq: ptr::null_mut(),
                cap: ibv_qp_cap {
                    max_send_wr: Self::MAX_SEND_WR as u32,
                    max_recv_wr: Self::MAX_SEND_WR as u32,
                    max_send_sge: 4,
                    max_recv_sge: 4,
                    max_inline_data: 0,
                },
                qp_type: ibv_qp_type::IBV_QPT_RC,
                sq_sig_all: 0, // do not signal every wr; caller controls explicitly
            };
            let qp_raw = ibv_create_qp(ctx.pd.as_ptr(), &mut attr);
            let qp = NonNull::new(qp_raw).ok_or_else(|| {
                anyhow!("ibv_create_qp failed: {}", std::io::Error::last_os_error())
            })?;

            // Pick a random PSN (Packet Serial Number). Cryptographic randomness not required.
            // Use the low 24 bits of the timestamp.
            let psn = (std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_nanos() as u32)
                .unwrap_or(0))
                & 0xFFFFFF;

            let local = QpInfo {
                qpn: (*qp_raw).qp_num,
                psn,
                gid: ctx.local_gid,
            };

            tracing::info!("RcQp created: qpn={} psn=0x{:x}", local.qpn, local.psn);

            Ok(Self {
                qp,
                retired_writes: Mutex::new(Vec::new()),
                retired_extents: Mutex::new(Vec::new()),
                retired_pins: Mutex::new(Vec::new()),
                local,
            })
        }
    }

    /// Transition to INIT. Set port and access flags.
    pub fn to_init(&self, port_num: u8) -> Result<()> {
        unsafe {
            let mut attr: ibv_qp_attr = std::mem::zeroed();
            attr.qp_state = ibv_qp_state::IBV_QPS_INIT;
            attr.pkey_index = 0;
            attr.port_num = port_num;
            // Allow remote WRITE/READ on our MR (direction here is server WRITE to client, but symmetric permissions ease debugging)
            attr.qp_access_flags = (ibv_access_flags::IBV_ACCESS_LOCAL_WRITE.0
                | ibv_access_flags::IBV_ACCESS_REMOTE_WRITE.0
                | ibv_access_flags::IBV_ACCESS_REMOTE_READ.0)
                as i32 as u32;

            let mask = ibv_qp_attr_mask::IBV_QP_STATE
                | ibv_qp_attr_mask::IBV_QP_PKEY_INDEX
                | ibv_qp_attr_mask::IBV_QP_PORT
                | ibv_qp_attr_mask::IBV_QP_ACCESS_FLAGS;
            let rc = ibv_modify_qp(self.qp.as_ptr(), &mut attr, mask.0 as i32);
            if rc != 0 {
                return Err(anyhow!(
                    "modify_qp -> INIT failed: rc={} errno={}",
                    rc,
                    std::io::Error::last_os_error()
                ));
            }
            Ok(())
        }
    }

    /// Transition to RTR (Ready-To-Receive). Requires remote QP info + path MTU + GID index.
    pub fn to_rtr(&self, remote: &QpInfo, port_num: u8, gid_index: u8) -> Result<()> {
        unsafe {
            let mut attr: ibv_qp_attr = std::mem::zeroed();
            attr.qp_state = ibv_qp_state::IBV_QPS_RTR;
            attr.path_mtu = ibv_mtu::IBV_MTU_1024; // align with hardware active_mtu
            attr.dest_qp_num = remote.qpn;
            attr.rq_psn = remote.psn;
            attr.max_dest_rd_atomic = 1;
            attr.min_rnr_timer = 12;

            // AH (address handle) — RoCE v2 uses GID-based addressing
            attr.ah_attr.is_global = 1;
            attr.ah_attr.dlid = 0;
            attr.ah_attr.sl = 0;
            attr.ah_attr.src_path_bits = 0;
            attr.ah_attr.port_num = port_num;
            attr.ah_attr.grh.dgid = remote.gid;
            attr.ah_attr.grh.flow_label = 0;
            attr.ah_attr.grh.hop_limit = 1;
            attr.ah_attr.grh.sgid_index = gid_index;
            attr.ah_attr.grh.traffic_class = 0;

            let mask = ibv_qp_attr_mask::IBV_QP_STATE
                | ibv_qp_attr_mask::IBV_QP_AV
                | ibv_qp_attr_mask::IBV_QP_PATH_MTU
                | ibv_qp_attr_mask::IBV_QP_DEST_QPN
                | ibv_qp_attr_mask::IBV_QP_RQ_PSN
                | ibv_qp_attr_mask::IBV_QP_MAX_DEST_RD_ATOMIC
                | ibv_qp_attr_mask::IBV_QP_MIN_RNR_TIMER;
            let rc = ibv_modify_qp(self.qp.as_ptr(), &mut attr, mask.0 as i32);
            if rc != 0 {
                return Err(anyhow!(
                    "modify_qp -> RTR failed: rc={} errno={}",
                    rc,
                    std::io::Error::last_os_error()
                ));
            }
            Ok(())
        }
    }

    /// Transition to RTS (Ready-To-Send). After this, post_send is allowed.
    pub fn to_rts(&self) -> Result<()> {
        unsafe {
            let mut attr: ibv_qp_attr = std::mem::zeroed();
            attr.qp_state = ibv_qp_state::IBV_QPS_RTS;
            attr.timeout = 14;
            attr.retry_cnt = 7;
            attr.rnr_retry = 7;
            attr.sq_psn = self.local.psn;
            attr.max_rd_atomic = 1;

            let mask = ibv_qp_attr_mask::IBV_QP_STATE
                | ibv_qp_attr_mask::IBV_QP_TIMEOUT
                | ibv_qp_attr_mask::IBV_QP_RETRY_CNT
                | ibv_qp_attr_mask::IBV_QP_RNR_RETRY
                | ibv_qp_attr_mask::IBV_QP_SQ_PSN
                | ibv_qp_attr_mask::IBV_QP_MAX_QP_RD_ATOMIC;
            let rc = ibv_modify_qp(self.qp.as_ptr(), &mut attr, mask.0 as i32);
            if rc != 0 {
                return Err(anyhow!(
                    "modify_qp -> RTS failed: rc={} errno={}",
                    rc,
                    std::io::Error::last_os_error()
                ));
            }
            Ok(())
        }
    }

    /// Post an RDMA WRITE: copy local [local_addr, local_addr+len) to remote [remote_addr, remote_addr+len).
    ///
    /// `wr_id`: user-defined id returned in the CQE, used to correlate requests.
    /// `signaled`: whether to generate a CQE (batched WRITEs typically only signal the last one).
    pub fn post_write(
        &self,
        wr_id: u64,
        local_addr: u64,
        local_lkey: u32,
        remote_addr: u64,
        remote_rkey: u32,
        len: u32,
        signaled: bool,
    ) -> Result<()> {
        unsafe {
            let mut sge = ibv_sge {
                addr: local_addr,
                length: len,
                lkey: local_lkey,
            };
            let mut wr: ibv_send_wr = std::mem::zeroed();
            wr.wr_id = wr_id;
            wr.sg_list = &mut sge;
            wr.num_sge = 1;
            wr.opcode = ibv_wr_opcode::IBV_WR_RDMA_WRITE;
            wr.send_flags = if signaled {
                ibv_send_flags::IBV_SEND_SIGNALED.0
            } else {
                0
            };
            wr.wr.rdma.remote_addr = remote_addr;
            wr.wr.rdma.rkey = remote_rkey;

            let mut bad_wr: *mut ibv_send_wr = ptr::null_mut();
            let rc = ibv_post_send(self.qp.as_ptr(), &mut wr, &mut bad_wr);
            if rc != 0 {
                return Err(anyhow!("ibv_post_send failed: rc={}", rc));
            }
            Ok(())
        }
    }

    /// Wait for N work completions. Simple busy poll for PoC use.
    pub fn poll_n(cq: NonNull<ibv_cq>, expected: usize) -> Result<()> {
        Self::poll_n_timeout(cq, expected, std::time::Duration::from_secs(30))
    }

    /// Wait for N work completions within a caller-selected deadline.
    pub fn poll_n_timeout(
        cq: NonNull<ibv_cq>,
        expected: usize,
        timeout: std::time::Duration,
    ) -> Result<()> {
        unsafe {
            // ibv_wc does not implement Clone; use push instead of vec!.
            let mut wcs: Vec<ibv_wc> = Vec::with_capacity(expected.max(1));
            for _ in 0..expected.max(1) {
                wcs.push(std::mem::zeroed());
            }
            let mut got = 0;
            let mut first_error: Option<String> = None;
            let start = std::time::Instant::now();
            while got < expected {
                let n = ibv_poll_cq(
                    cq.as_ptr(),
                    (expected - got) as i32,
                    wcs[got..].as_mut_ptr(),
                );
                if n < 0 {
                    return Err(anyhow!("ibv_poll_cq error"));
                }
                if n > 0 {
                    for i in got..(got + n as usize) {
                        if wcs[i].status != ibv_wc_status::IBV_WC_SUCCESS {
                            first_error.get_or_insert_with(|| {
                                format!(
                                    "WR {} failed: status={} ({})",
                                    wcs[i].wr_id,
                                    wcs[i].status,
                                    wc_status_str(wcs[i].status),
                                )
                            });
                        }
                    }
                    got += n as usize;
                }
                if start.elapsed() >= timeout {
                    return Err(anyhow!(
                        "poll_n timeout after {}ms, got {}/{}",
                        timeout.as_millis(),
                        got,
                        expected
                    ));
                }
            }
            match first_error {
                Some(error) => Err(anyhow!(error)),
                None => Ok(()),
            }
        }
    }

    /// 非阻塞收割: poll 当前已完成的 CQE (最多 `max`), 立即返回收到的数量.
    /// 用于流水线中的机会式回收 — post 间隙顺手清 CQ, 避免凑满窗口后长阻塞.
    pub fn poll_available(cq: NonNull<ibv_cq>, max: usize) -> Result<(usize, Option<String>)> {
        unsafe {
            let cap = max.max(1);
            let mut wcs: Vec<ibv_wc> = Vec::with_capacity(cap);
            for _ in 0..cap {
                wcs.push(std::mem::zeroed());
            }
            let n = ibv_poll_cq(cq.as_ptr(), cap as i32, wcs.as_mut_ptr());
            if n < 0 {
                return Err(anyhow!("ibv_poll_cq error"));
            }
            Ok(Self::summarize_completions(&wcs[..n as usize]))
        }
    }

    fn summarize_completions(wcs: &[ibv_wc]) -> (usize, Option<String>) {
        let first_error = wcs
            .iter()
            .find(|wc| wc.status != ibv_wc_status::IBV_WC_SUCCESS)
            .map(|wc| {
                format!(
                    "WR {} failed: status={} ({})",
                    wc.wr_id,
                    wc.status,
                    wc_status_str(wc.status)
                )
            });
        (wcs.len(), first_error)
    }

    /// Retain an uncertain local WRITE source until this QP is destroyed.
    /// Used when polling cannot prove a signaled WRITE has quiesced.
    pub fn retain_uncertain_write(&self, mr: MemRegion, source: Bytes) {
        self.retired_writes.lock().unwrap().push((mr, source));
    }

    /// Keep a slab allocation pinned until QP destruction when a CQ poll
    /// cannot prove every WRITE has stopped using it.
    pub fn retain_uncertain_extent(&self, extent: SlabExtent) {
        self.retired_extents.lock().unwrap().push(extent);
    }

    /// Keep a cached slab entry pinned until the QP can no longer read it.
    pub fn retain_uncertain_pin(&self, pin: Arc<SlabExtent>) {
        self.retired_pins.lock().unwrap().push(pin);
    }
}

fn wc_status_str(status: u32) -> &'static str {
    match status {
        0 => "SUCCESS",
        1 => "LOC_LEN_ERR",
        2 => "LOC_QP_OP_ERR",
        4 => "LOC_PROT_ERR",
        5 => "WR_FLUSH_ERR",
        10 => "REM_ACCESS_ERR",
        12 => "REM_OP_ERR",
        13 => "RETRY_EXC_ERR",
        14 => "RNR_RETRY_EXC_ERR",
        _ => "OTHER",
    }
}

impl Drop for RcQp {
    fn drop(&mut self) {
        // Retained WRITE sources and slab pins drop immediately after this
        // QP. An unsuccessful destroy cannot prove they are safe to release.
        let rc = unsafe { ibv_destroy_qp(self.qp.as_ptr()) };
        if rc != 0 {
            const MESSAGE: &[u8] = b"ContextStore RDMA server QP destruction failed; aborting\n";
            unsafe { libc::write(libc::STDERR_FILENO, MESSAGE.as_ptr().cast(), MESSAGE.len()) };
            std::process::abort();
        }
    }
}

#[cfg(test)]
mod completion_tests {
    use super::*;

    #[test]
    fn failed_cqe_is_still_counted_as_consumed() {
        let mut completion: ibv_wc = unsafe { std::mem::zeroed() };
        completion.wr_id = 9;
        completion.status = 12;
        let (count, error) = RcQp::summarize_completions(&[completion]);
        assert_eq!(count, 1);
        assert!(error.expect("failed status").contains("WR 9 failed"));
    }
}
