# KVService configuration

`contextstore-server` reads one TOML configuration file at startup. The file is
selected with `--config` / `-c`; when omitted, the server reads
`configs/server.toml` relative to its current working directory.

Redis is an external dependency, not a second KVService config file. The server
connects to Redis through `[metadata].redis_url` and fails startup if the Redis
metadata store is unavailable.

## Example files

| File | Purpose |
|------|---------|
| `server.toml` | Default local development config using `./data/nvme*` paths. |
| `server-test.toml` | Test environment config using `/mnt/cs/nvme2..9`. |
| `server-nvmeof.toml` | NVMe-oF / JBOF config using mounted remote namespaces. |

Use these files as deployment templates and keep environment-specific values
such as disk mount paths, advertised endpoints, and Redis URLs outside source
control when they contain private infrastructure details.

## Start commands

From the repository root:

```bash
make build
./target/release/contextstore-server \
    --config kv-service/configs/server.toml
```

From the `kv-service/` directory:

```bash
make build
../target/release/contextstore-server --config configs/server.toml
```

The log level can be set with `--log-level`:

```bash
../target/release/contextstore-server \
    --config configs/server.toml \
    --log-level info
```

## Minimal config

Every section has Rust-side defaults, but production configs should be explicit
about storage paths, Redis metadata, and public endpoints.

```toml
[api]
listen = "0.0.0.0:50051"
max_connections = 1000

[storage]
devices = ["./data/nvme0"]
data_subdir = "contextstore"
striping_threshold = 268435456
striping_chunk_size = 67108864
rdma_stream_chunk_size = 4194304
verify_stripe_checksums = false

[memory_tier]
capacity_mb = 4096
slab_size_mb = 64
use_pinned_memory = false

[io_executor]
kind = "tier_a"
thread_pool_size = 32
io_uring_depth = 256

[router]
strategy = "object_hash"

[metadata]
redis_url = "redis://127.0.0.1:6379/"
redis_key_prefix = "contextstore:metadata:"
redis_connect_timeout_ms = 1000
redis_command_timeout_ms = 1000

[metrics]
enabled = false
listen = "0.0.0.0:9090"
```

## Sections

### `[api]`

| Field | Default | Description |
|-------|---------|-------------|
| `listen` | `"0.0.0.0:50051"` | gRPC listen address. |
| `max_connections` | `1000` | Intended connection limit for the service. |

### `[storage]`

| Field | Default | Description |
|-------|---------|-------------|
| `devices` | `["./data/nvme0"]` | Mount directories or directories backing local/NVMe-oF devices. At least one device is required. |
| `data_subdir` | `"contextstore"` | Subdirectory created below each configured device. |
| `striping_threshold` | `268435456` | Object size threshold in bytes for internal striping. `0` disables striping. |
| `striping_chunk_size` | `67108864` | Chunk size in bytes when striping is enabled. |
| `rdma_stream_chunk_size` | `4194304` | Maximum 4 KiB-aligned range emitted by the RDMA disk-miss read stream. It preserves the physical striping layout while overlapping disk reads and RDMA writes. 4 MB is the measured sweet spot: 8 MB leaves the per-disk queue underfed on cold reads, 2 MB adds no further gain, 16 MB regresses. |
| `verify_stripe_checksums` | `false` | When enabled, persist an xxh3-64 checksum per physical stripe and validate it before serving disk reads. Values written before enabling it are treated as cache misses until rewritten. Disabled by default to avoid the extra CPU memory scan on the normal performance path. |

KVService stores object data under each device's `data_subdir`. It creates
subdirectories and object files; it does not format raw devices.

For an RDMA disk miss, integrity mode holds each physical stripe until all of
its `rdma_stream_chunk_size` reads complete and the full stripe checksum
passes. This preserves data integrity, but releases RDMA writes at stripe
granularity rather than the normal subrange granularity and can increase
first-byte latency. Keep the option disabled for latency-sensitive cache reads
unless this integrity trade-off is required.

### `[memory_tier]`

| Field | Default | Description |
|-------|---------|-------------|
| `capacity_mb` | `4096` | L1 memory cache capacity. |
| `slab_size_mb` | `64` | Slab allocation size for the memory tier. |
| `use_pinned_memory` | `false` | Enables pinned memory when the runtime environment supports it. |

### `[io_executor]`

| Field | Default | Description |
|-------|---------|-------------|
| `kind` | `"tier_a"` | I/O backend: `tier_a`, `tier_b`, or `tier_c`. |
| `thread_pool_size` | `32` | Worker count for the thread-pool path. |
| `io_uring_depth` | `256` | Ring depth for the `tier_b` io_uring path. |

`tier_a` works with the default build. `tier_b` requires a Linux build with the
`io-uring` Cargo feature. `tier_c` is reserved for the SPDK path.

### `[router]`

| Field | Default | Description |
|-------|---------|-------------|
| `strategy` | `"object_hash"` | Object routing strategy. `object_hash` is currently the supported value. |

### `[metadata]`

| Field | Default | Description |
|-------|---------|-------------|
| `redis_url` | `"redis://127.0.0.1:6379/"` | Shared Redis metadata endpoint. Must not be empty. |
| `redis_key_prefix` | `"contextstore:metadata:"` | Prefix for all KVService metadata keys in Redis. Must not be empty. |
| `redis_connect_timeout_ms` | `1000` | Redis connection timeout in milliseconds. Must be greater than `0`. |
| `redis_command_timeout_ms` | `1000` | Redis read/write command timeout in milliseconds. Must be greater than `0`. |

All KVService nodes that should share object metadata must use the same
`redis_url` and `redis_key_prefix`. Use different prefixes to isolate
environments that share one Redis instance.

When `storage.verify_stripe_checksums = true`, enable it on every coordinator
and data node in a placement cluster. The coordinator rejects a distributed
write if any data node does not return a stripe checksum. Upgrade Python
clients too: regenerate their protobuf stubs with `make proto` before building
or packaging the client, so cached placement descriptors retain the checksum
field during forwarding.

### `[cluster]`

This section is optional. When `cluster.data_nodes` is empty, the server runs in
single-node placement mode. Cross-node placement is enabled only when more than
one data node is configured and the object is large enough to be striped.

```toml
[cluster]
node_id = "node-a"
grpc_advertise = "10.0.0.11:50051"
rdma_advertise = "10.0.0.11:50053"

[[cluster.data_nodes]]
node_id = "node-a"
grpc_endpoint = "10.0.0.11:50051"
rdma_endpoint = "10.0.0.11:50053"

[[cluster.data_nodes]]
node_id = "node-b"
grpc_endpoint = "10.0.0.12:50051"
rdma_endpoint = "10.0.0.12:50053"
```

| Field | Default | Description |
|-------|---------|-------------|
| `node_id` | `""` | This node's stable ID. If empty, the server reads `CS_NODE_ID`, then falls back to `local`. |
| `grpc_advertise` | `""` | Public gRPC endpoint for this node. If empty, the server reads `CS_GRPC_ADVERTISE`, then falls back to `[api].listen`. |
| `rdma_advertise` | `""` | Public RDMA endpoint for this node. If empty, the server reads `CS_RDMA_ADVERTISE`, then falls back to empty. |
| `data_nodes` | `[]` | Data nodes eligible for object stripe placement. Each entry requires `grpc_endpoint`; `node_id` and `rdma_endpoint` are optional. |

### `[metrics]`

| Field | Default | Description |
|-------|---------|-------------|
| `enabled` | `false` | Enables the Prometheus exporter when the binary is built with the `metrics` feature. |
| `listen` | `"0.0.0.0:9090"` | Prometheus HTTP listen address. |

If `metrics.enabled = true` but the binary was not built with `--features
metrics`, the server still starts and logs a warning.

The exporter uses only low-cardinality labels. Storage I/O metrics are grouped
by `operation`, `device`, `executor`, `mode`, and `status`; Redis metadata
metrics are grouped by operation and status; RDMA metrics are grouped by NIC.
Object keys, file paths, request IDs, and namespaces are intentionally not
Prometheus labels. Use `contextstore_server::storage_io` debug logs when an
individual path must be inspected.

Key metrics for performance tuning include:

- `kvservice_storage_io_total`, `kvservice_storage_io_bytes_total`,
  `kvservice_storage_io_duration_seconds`, and
  `kvservice_storage_io_inflight` for per-device I/O throughput, latency, and
  concurrency. `mode` identifies the logical storage path; `aligned` may use
  O_DIRECT or a buffered fallback depending on executor and filesystem support.
  For `mode="batch"`, `vectored`, and `aligned` striped I/O,
  the duration is the wall-clock submission-to-completion time of the parallel
  batch and is emitted for each participating device; it is not a per-device
  device-service-time measurement.
- `kvservice_metadata_operations_total`,
  `kvservice_metadata_operation_duration_seconds`, and
  `kvservice_metadata_reconnect_total` for Redis metadata pressure.
- `device_used_bytes` for per-device capacity. It is initialized once at
  startup and updated as ContextStore writes or deletes files; scraping the
  exporter does not walk the data directory.
- `kvservice_rdma_bytes_total`,
  `kvservice_rdma_transfer_duration_seconds`,
  `kvservice_rdma_errors_total`, and `kvservice_rdma_connections` for the
  RDMA data path.

### `[gds]`

This section is optional and only has an effect when the server is built with
the `gds` feature.

The default `make build` does not include GDS. Build it explicitly on a Linux
host that has CUDA, `libcufile.so`, and the `nvidia-fs` kernel module:

```bash
make build SERVER_FEATURES=io-uring,rdma,metrics,gds
```

| Field | Default | Description |
|-------|---------|-------------|
| `enabled` | `false` | Attempts to initialize GPUDirect Storage support. |
| `device` | `-1` | CUDA device ordinal. `-1` means do not force a device. |

GDS initialization failures are logged as warnings and normal I/O paths remain
available. The current implementation uses CUDA IPC for a GPU buffer on the
same host and supports only unstriped local objects. It does not provide
striped or cross-node GDS reads or writes.

## Deployment notes

- Create all configured storage device directories before startup, or run the
  server with permissions that can create the needed subdirectories.
- Start Redis before KVService. For local testing, `redis-server --port 6379`
  is sufficient.
- In Kubernetes, provide Redis separately and set `[metadata].redis_url` to its
  service DNS name, for example `redis://contextstore-redis:6379/`.
- For multi-node deployments, every node must use the same Redis metadata store
  and a consistent `cluster.data_nodes` list.
